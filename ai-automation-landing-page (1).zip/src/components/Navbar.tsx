import { useState } from "react";
import { Menu, X, Zap } from "lucide-react";

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="relative h-9 w-9 rounded-lg bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-violet-500/25 group-hover:shadow-violet-500/40 transition-shadow">
            <Zap className="h-5 w-5 text-white" />
          </div>
          <span className="text-xl font-bold text-white tracking-tight">
            Synapse<span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">Flow</span>
          </span>
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm text-slate-400 hover:text-white transition-colors">Features</a>
          <a href="#how-it-works" className="text-sm text-slate-400 hover:text-white transition-colors">How It Works</a>
          <a href="#pricing" className="text-sm text-slate-400 hover:text-white transition-colors">Pricing</a>
          <a href="#waitlist" className="text-sm font-semibold text-slate-900 bg-gradient-to-r from-violet-400 to-cyan-400 px-5 py-2 rounded-full hover:opacity-90 transition-opacity">
            Join Waitlist
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-slate-950/95 backdrop-blur-xl border-t border-white/5 px-6 py-6 space-y-4">
          <a href="#features" onClick={() => setMobileOpen(false)} className="block text-slate-300 hover:text-white transition-colors">Features</a>
          <a href="#how-it-works" onClick={() => setMobileOpen(false)} className="block text-slate-300 hover:text-white transition-colors">How It Works</a>
          <a href="#pricing" onClick={() => setMobileOpen(false)} className="block text-slate-300 hover:text-white transition-colors">Pricing</a>
          <a href="#waitlist" onClick={() => setMobileOpen(false)} className="block text-center font-semibold text-slate-900 bg-gradient-to-r from-violet-400 to-cyan-400 px-5 py-2.5 rounded-full">
            Join Waitlist
          </a>
        </div>
      )}
    </nav>
  );
}

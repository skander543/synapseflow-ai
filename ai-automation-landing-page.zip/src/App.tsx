import { useState, useEffect, useCallback } from 'react';
import { Search, Bell, Plus, X, CheckCircle2, AlertTriangle, Info, Zap, Bot, Workflow, BarChart3, Settings as SettingsIcon, Plug, Book, ChevronDown, ChevronRight, ExternalLink, Clock, Trash2, Check, Mail } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Workflows from './pages/Workflows';
import WorkflowBuilder from './pages/WorkflowBuilder';
import Agents from './pages/Agents';
import Integrations from './pages/Integrations';
import Analytics from './pages/Analytics';
import Settings from './pages/Settings';

interface Notification {
  id: string;
  title: string;
  desc: string;
  time: string;
  type: 'success' | 'warning' | 'info' | 'error';
  read: boolean;
}

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showCmdPalette, setShowCmdPalette] = useState(false);
  const [cmdSearch, setCmdSearch] = useState('');

  const [notifications, setNotifications] = useState<Notification[]>([
    { id: '1', title: 'Workflow "Lead Qualification" completed', desc: '2,341 leads processed successfully with 99.2% accuracy', time: '2 min ago', type: 'success', read: false },
    { id: '2', title: 'Agent SocialAI needs attention', desc: 'Training paused due to API rate limit — consider upgrading the AI model quota', time: '12 min ago', type: 'warning', read: false },
    { id: '3', title: 'New integration available: HubSpot v3', desc: 'Enhanced CRM sync with bi-directional support and custom field mapping', time: '1 hr ago', type: 'info', read: false },
    { id: '4', title: 'Invoice Processing completed batch #847', desc: '234 invoices processed, 3 flagged for review, $1.2M total value', time: '2 hrs ago', type: 'success', read: false },
    { id: '5', title: 'Weekly performance report ready', desc: 'Your automations saved 164 hours this week — up 18% from last week', time: '5 hrs ago', type: 'info', read: true },
    { id: '6', title: 'Support ticket volume spike detected', desc: 'SupportBot handled 127 tickets in the last hour — 34% above average', time: '6 hrs ago', type: 'warning', read: true },
    { id: '7', title: 'Competitor Price Monitor alert', desc: 'Competitor XYZ dropped prices by 15% on 3 products in your tracked list', time: '8 hrs ago', type: 'error', read: true },
    { id: '8', title: 'Salesforce sync completed', desc: '4,521 records synced with 3 conflicts auto-resolved', time: '12 hrs ago', type: 'success', read: true },
    { id: '9', title: 'New team member invited', desc: 'sarah@company.com has been invited to join your workspace', time: '1 day ago', type: 'info', read: true },
    { id: '10', title: 'Monthly billing processed', desc: 'Pro Plan — $149.00 charged to Visa ending 4242', time: '2 days ago', type: 'info', read: true },
  ]);

  const [notifFilter, setNotifFilter] = useState<'all' | 'unread'>('all');

  // Help page state
  const [expandedDoc, setExpandedDoc] = useState<string | null>('getting-started');
  const [helpSearch, setHelpSearch] = useState('');

  // Keyboard shortcut for cmd palette
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowCmdPalette(true);
        setCmdSearch('');
      }
      if (e.key === 'Escape') {
        setShowCmdPalette(false);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const deleteNotif = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const pageTitle: Record<string, string> = {
    dashboard: 'Dashboard',
    workflows: 'Workflows',
    builder: 'Workflow Builder',
    agents: 'AI Agents',
    integrations: 'Integrations',
    analytics: 'Analytics',
    settings: 'Settings',
    notifications: 'Notifications',
    help: 'Help & Docs',
  };

  const cmdActions = [
    { label: 'Go to Dashboard', icon: <BarChart3 className="w-4 h-4" />, action: () => setActiveTab('dashboard') },
    { label: 'Go to Workflows', icon: <Workflow className="w-4 h-4" />, action: () => setActiveTab('workflows') },
    { label: 'New Workflow', icon: <Plus className="w-4 h-4" />, action: () => setActiveTab('builder') },
    { label: 'Go to AI Agents', icon: <Bot className="w-4 h-4" />, action: () => setActiveTab('agents') },
    { label: 'Go to Integrations', icon: <Plug className="w-4 h-4" />, action: () => setActiveTab('integrations') },
    { label: 'Go to Analytics', icon: <BarChart3 className="w-4 h-4" />, action: () => setActiveTab('analytics') },
    { label: 'Go to Settings', icon: <SettingsIcon className="w-4 h-4" />, action: () => setActiveTab('settings') },
    { label: 'Notifications', icon: <Bell className="w-4 h-4" />, action: () => setActiveTab('notifications') },
    { label: 'Help & Docs', icon: <Book className="w-4 h-4" />, action: () => setActiveTab('help') },
  ].filter(a => a.label.toLowerCase().includes(cmdSearch.toLowerCase()));

  // Help docs content
  const helpDocs = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: '🚀',
      sections: [
        { q: 'What is SynapseFlow AI?', a: 'SynapseFlow AI is an AI-powered automation platform that helps businesses automate repetitive tasks using intelligent agents, visual workflow builders, and 500+ integrations. Our platform can process leads, handle customer support, manage invoices, and much more — all powered by state-of-the-art AI models.' },
        { q: 'How do I create my first workflow?', a: '1. Click "New Workflow" or navigate to the Builder\n2. Add a Trigger node (e.g., "Email Received")\n3. Add Action nodes (e.g., "AI Classify", "Update Database")\n4. Configure each node with your settings\n5. Click "Test Run" to validate\n6. Click "Save" to activate' },
        { q: 'What AI models are supported?', a: 'We support GPT-4o, GPT-4o Mini, Claude 3.5 Sonnet, and Llama 3.1 70B. You can choose the best model for each task based on speed, cost, and capability requirements.' },
      ]
    },
    {
      id: 'workflows',
      title: 'Workflow Guide',
      icon: '⚡',
      sections: [
        { q: 'What are triggers?', a: 'Triggers are the starting point of a workflow. They listen for events like incoming emails, webhook calls, scheduled times, or form submissions. When the trigger condition is met, the workflow executes.' },
        { q: 'How do conditions work?', a: 'Condition nodes (If/Else) allow you to branch your workflow based on data. For example, "if lead_score > 70" routes high-quality leads differently from low-quality ones. You can use any data from previous nodes.' },
        { q: 'Can I loop through items?', a: 'Yes! Use the Loop node to iterate over arrays of data. For example, process each row in a spreadsheet or each email in an inbox. Each iteration runs the subsequent nodes independently.' },
      ]
    },
    {
      id: 'agents',
      title: 'AI Agents',
      icon: '🤖',
      sections: [
        { q: 'What are AI Agents?', a: 'AI Agents are autonomous workers that perform specific tasks. Unlike simple automations, agents can learn, adapt, and make decisions. Each agent has a system prompt, AI model, and skills that define its behavior.' },
        { q: 'How do I deploy an agent?', a: '1. Go to AI Agents page\n2. Click "Deploy Agent"\n3. Give it a name and role\n4. Select an AI model\n5. Define skills and system prompt\n6. Click Deploy — your agent goes online immediately' },
        { q: 'Can I chat with my agents?', a: 'Yes! Click on any agent, expand it, and click "Chat". You can have real-time conversations with your agents to test them, ask for reports, or give instructions.' },
      ]
    },
    {
      id: 'api',
      title: 'API Reference',
      icon: '📖',
      sections: [
        { q: 'Authentication', a: 'All API requests require an API key in the Authorization header:\n\nAuthorization: Bearer sf_live_your_key_here\n\nGenerate API keys in Settings → API Keys.' },
        { q: 'Trigger a Workflow', a: 'POST /v1/workflows/{id}/trigger\n\nBody: { "data": { ... } }\n\nResponse: { "run_id": "...", "status": "queued" }' },
        { q: 'List Agents', a: 'GET /v1/agents\n\nResponse: { "agents": [...], "total": 6 }' },
        { q: 'Rate Limits', a: 'Starter: 100 req/min\nPro: 1,000 req/min\nEnterprise: Custom\n\nRate limit headers are included in all responses.' },
      ]
    },
    {
      id: 'integrations',
      title: 'Integrations',
      icon: '🔌',
      sections: [
        { q: 'How do I connect an integration?', a: 'Go to Integrations page, find the service you want, and click "Connect". You\'ll be redirected to authorize SynapseFlow with that service. Once connected, you can use it in any workflow.' },
        { q: 'Which integrations are available?', a: 'We support 500+ integrations including: Slack, Gmail, Salesforce, HubSpot, Stripe, Shopify, Google Sheets, Notion, Jira, PostgreSQL, OpenAI, AWS S3, and many more.' },
        { q: 'Can I build custom integrations?', a: 'Yes! Use the HTTP Request action node to connect to any API. For webhooks, use our Webhook trigger with your custom endpoint URL found in Settings → API Keys.' },
      ]
    },
    {
      id: 'support',
      title: 'Contact Support',
      icon: '💬',
      sections: [
        { q: 'How can I get help?', a: 'You can reach us at:\n• Email: support@synapseflow.ai\n• Live Chat: Click the chat icon in the bottom right\n• Phone: +1 (888) 555-FLOW\n• Response time: < 1 hour for Pro, < 4 hours for Starter' },
        { q: 'Do you offer onboarding help?', a: 'Yes! Pro and Enterprise plans include a free onboarding session with our automation specialists. We\'ll help you set up your first workflows and agents.' },
        { q: 'Where can I report bugs?', a: 'Report bugs at bugs@synapseflow.ai or through our GitHub issues page. Include steps to reproduce, expected behavior, and any error messages.' },
      ]
    },
  ];

  const filteredDocs = helpDocs.filter(d =>
    !helpSearch || d.title.toLowerCase().includes(helpSearch.toLowerCase()) ||
    d.sections.some(s => s.q.toLowerCase().includes(helpSearch.toLowerCase()) || s.a.toLowerCase().includes(helpSearch.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-[#0a0e1a] flex">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} unreadNotifs={unreadCount} />

      {/* Main content area */}
      <div className="flex-1 ml-64">
        {/* Top header */}
        <header className="h-16 border-b border-slate-800/60 bg-slate-950/80 backdrop-blur-xl flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <h2 className="text-white font-semibold">{pageTitle[activeTab] || 'Dashboard'}</h2>
          </div>
          <div className="flex items-center gap-3">
            {/* Search / Cmd Palette Trigger */}
            <button
              onClick={() => { setShowCmdPalette(true); setCmdSearch(''); }}
              className="hidden md:flex items-center gap-2 w-64 pl-10 pr-4 py-2 bg-slate-900/80 border border-slate-800/60 rounded-xl text-slate-500 text-sm hover:border-violet-500/30 transition-colors relative"
            >
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              Search anything...
              <span className="ml-auto text-xs bg-slate-800 px-1.5 py-0.5 rounded text-slate-500">⌘K</span>
            </button>

            {/* Quick action */}
            <button
              onClick={() => setActiveTab('builder')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-violet-500/25 transition-all"
            >
              <Plus className="w-4 h-4" /> New
            </button>

            {/* Notifications */}
            <button
              onClick={() => setActiveTab('notifications')}
              className="relative p-2 rounded-xl hover:bg-slate-800/50 text-slate-400 hover:text-white transition-colors"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-0.5 right-0.5 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* User avatar */}
            <button
              onClick={() => setActiveTab('settings')}
              className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center text-white text-sm font-bold hover:ring-2 hover:ring-violet-400/30 transition-all"
            >
              J
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="p-6">
          {activeTab === 'dashboard' && <Dashboard onNavigate={setActiveTab} />}
          {activeTab === 'workflows' && <Workflows onNavigate={setActiveTab} />}
          {activeTab === 'builder' && <WorkflowBuilder />}
          {activeTab === 'agents' && <Agents />}
          {activeTab === 'integrations' && <Integrations />}
          {activeTab === 'analytics' && <Analytics />}
          {activeTab === 'settings' && <Settings />}

          {/* FULL NOTIFICATIONS PAGE */}
          {activeTab === 'notifications' && (
            <div className="animate-fade-in space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                    <Bell className="w-7 h-7 text-violet-400" /> Notifications
                  </h1>
                  <p className="text-slate-400 text-sm mt-1">{unreadCount} unread · {notifications.length} total</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setNotifFilter(notifFilter === 'all' ? 'unread' : 'all')}
                    className={`px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
                      notifFilter === 'unread' ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : 'bg-slate-900/80 text-slate-400 border border-slate-800/60 hover:text-white'
                    }`}
                  >
                    {notifFilter === 'unread' ? 'Showing Unread' : 'Show Unread Only'}
                  </button>
                  {unreadCount > 0 && (
                    <button onClick={markAllRead} className="px-3 py-2 rounded-xl text-sm font-medium bg-slate-900/80 text-slate-400 border border-slate-800/60 hover:text-white transition-colors flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5" /> Mark All Read
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                {notifications
                  .filter(n => notifFilter === 'all' || !n.read)
                  .map((notif) => (
                  <div
                    key={notif.id}
                    className={`group relative p-4 bg-slate-900/80 border rounded-2xl transition-all hover:border-slate-700/60 ${
                      !notif.read ? 'border-violet-500/20 bg-violet-500/[0.02]' : 'border-slate-800/60'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`mt-0.5 w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                        notif.type === 'success' ? 'bg-emerald-500/10' :
                        notif.type === 'warning' ? 'bg-amber-500/10' :
                        notif.type === 'error' ? 'bg-red-500/10' :
                        'bg-blue-500/10'
                      }`}>
                        {notif.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                        {notif.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                        {notif.type === 'error' && <AlertTriangle className="w-4 h-4 text-red-400" />}
                        {notif.type === 'info' && <Info className="w-4 h-4 text-blue-400" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className={`font-medium text-sm ${!notif.read ? 'text-white' : 'text-slate-300'}`}>{notif.title}</p>
                          <div className="flex items-center gap-2 flex-shrink-0">
                            {!notif.read && (
                              <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
                            )}
                            <span className="text-xs text-slate-500 whitespace-nowrap flex items-center gap-1">
                              <Clock className="w-3 h-3" />{notif.time}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm text-slate-500 mt-0.5">{notif.desc}</p>
                        <div className="flex gap-2 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          {!notif.read && (
                            <button onClick={() => markAsRead(notif.id)} className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1">
                              <Check className="w-3 h-3" /> Mark read
                            </button>
                          )}
                          <button onClick={() => deleteNotif(notif.id)} className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1">
                            <Trash2 className="w-3 h-3" /> Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {notifications.filter(n => notifFilter === 'all' || !n.read).length === 0 && (
                  <div className="text-center py-16">
                    <Bell className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <h3 className="text-white font-semibold">No notifications</h3>
                    <p className="text-sm text-slate-500 mt-1">{notifFilter === 'unread' ? 'All caught up! No unread notifications.' : 'You have no notifications yet.'}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* FULL HELP & DOCS PAGE */}
          {activeTab === 'help' && (
            <div className="animate-fade-in space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Book className="w-7 h-7 text-violet-400" /> Help & Documentation
                </h1>
                <p className="text-slate-400 text-sm mt-1">Everything you need to know about SynapseFlow AI</p>
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  value={helpSearch}
                  onChange={e => setHelpSearch(e.target.value)}
                  placeholder="Search documentation..."
                  className="w-full pl-10 pr-4 py-3 bg-slate-900/80 border border-slate-800/60 rounded-xl text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-violet-500/50"
                />
              </div>

              {/* Quick links */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                {helpDocs.map(doc => (
                  <button
                    key={doc.id}
                    onClick={() => setExpandedDoc(doc.id)}
                    className={`p-4 rounded-xl text-left transition-all border ${
                      expandedDoc === doc.id ? 'bg-violet-500/10 border-violet-500/30' : 'bg-slate-900/80 border-slate-800/60 hover:border-violet-500/20'
                    }`}
                  >
                    <span className="text-2xl">{doc.icon}</span>
                    <p className="text-sm text-white font-medium mt-2">{doc.title}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{doc.sections.length} articles</p>
                  </button>
                ))}
              </div>

              {/* Doc sections */}
              <div className="space-y-3">
                {filteredDocs.map(doc => (
                  <div key={doc.id} className="bg-slate-900/80 border border-slate-800/60 rounded-2xl overflow-hidden">
                    <button
                      onClick={() => setExpandedDoc(expandedDoc === doc.id ? null : doc.id)}
                      className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-800/20 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{doc.icon}</span>
                        <div>
                          <h3 className="text-white font-semibold">{doc.title}</h3>
                          <p className="text-xs text-slate-500">{doc.sections.length} articles</p>
                        </div>
                      </div>
                      {expandedDoc === doc.id ? <ChevronDown className="w-5 h-5 text-slate-400" /> : <ChevronRight className="w-5 h-5 text-slate-400" />}
                    </button>
                    {expandedDoc === doc.id && (
                      <div className="border-t border-slate-800/60 animate-fade-in">
                        {doc.sections.map((section, i) => (
                          <div key={i} className="p-5 border-b border-slate-800/30 last:border-0">
                            <h4 className="text-white font-semibold text-sm flex items-center gap-2">
                              <Zap className="w-3.5 h-3.5 text-violet-400" />
                              {section.q}
                            </h4>
                            <div className="mt-2 text-sm text-slate-400 whitespace-pre-wrap leading-relaxed">
                              {section.a}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Contact support */}
              <div className="bg-gradient-to-r from-violet-600/20 via-purple-600/10 to-cyan-600/20 border border-violet-500/20 rounded-2xl p-6">
                <h3 className="text-white font-bold text-lg">Still need help?</h3>
                <p className="text-slate-400 text-sm mt-1">Our team is here to assist you. Reach out anytime.</p>
                <div className="flex flex-wrap gap-3 mt-4">
                  <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-violet-500/25 transition-all">
                    <Mail className="w-4 h-4" /> Email Support
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-slate-800/80 text-white text-sm font-semibold rounded-xl hover:bg-slate-700/80 transition-all border border-slate-700/50">
                    <ExternalLink className="w-4 h-4" /> API Docs
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Command Palette */}
      {showCmdPalette && (
        <div className="fixed inset-0 z-[200] flex items-start justify-center pt-[20vh] modal-backdrop" onClick={() => setShowCmdPalette(false)}>
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700/60 rounded-2xl shadow-2xl shadow-black/50 animate-bounce-in overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 px-4 border-b border-slate-800/60">
              <Search className="w-5 h-5 text-slate-500 flex-shrink-0" />
              <input
                value={cmdSearch}
                onChange={e => setCmdSearch(e.target.value)}
                placeholder="Type a command or search..."
                className="flex-1 py-4 bg-transparent text-white text-sm focus:outline-none placeholder:text-slate-500"
                autoFocus
              />
              <button onClick={() => setShowCmdPalette(false)} className="text-slate-500 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-72 overflow-y-auto p-2">
              {cmdActions.length > 0 ? cmdActions.map((action, i) => (
                <button
                  key={i}
                  onClick={() => { action.action(); setShowCmdPalette(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-300 hover:bg-violet-500/10 hover:text-white transition-colors"
                >
                  <span className="text-violet-400">{action.icon}</span>
                  {action.label}
                </button>
              )) : (
                <p className="text-sm text-slate-500 text-center py-4">No results found</p>
              )}
            </div>
            <div className="px-4 py-2 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-500">
              <span>↑↓ Navigate · ↵ Select · Esc Close</span>
              <span className="text-violet-400">SynapseFlow</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;

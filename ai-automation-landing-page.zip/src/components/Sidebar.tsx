import { useState } from 'react';
import {
  LayoutDashboard, Workflow, Bot, Plug, BarChart3, Settings, ChevronLeft,
  ChevronRight, Zap, HelpCircle, LogOut, Bell
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  unreadNotifs?: number;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'workflows', label: 'Workflows', icon: Workflow },
  { id: 'builder', label: 'Builder', icon: Zap },
  { id: 'agents', label: 'AI Agents', icon: Bot },
  { id: 'integrations', label: 'Integrations', icon: Plug },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
];

const bottomItems = [
  { id: 'notifications', label: 'Notifications', icon: Bell, badge: 0 },
  { id: 'help', label: 'Help & Docs', icon: HelpCircle },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export default function Sidebar({ activeTab, onTabChange, unreadNotifs = 0 }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className={`${collapsed ? 'w-[72px]' : 'w-64'} h-screen bg-slate-950 border-r border-slate-800/60 flex flex-col transition-all duration-300 fixed left-0 top-0 z-40`}>
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-slate-800/60">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center flex-shrink-0">
          <Zap className="w-5 h-5 text-white" />
        </div>
        {!collapsed && (
          <span className="ml-3 text-lg font-bold text-white tracking-tight">
            Synapse<span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">Flow</span>
          </span>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="ml-auto w-7 h-7 rounded-lg bg-slate-800/50 hover:bg-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Main menu */}
      <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        {!collapsed && <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-3 mb-2">Main</p>}
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center ${collapsed ? 'justify-center px-0' : 'px-3'} py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group relative ${
                isActive
                  ? 'bg-gradient-to-r from-violet-500/20 to-cyan-500/10 text-white shadow-lg shadow-violet-500/5'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-gradient-to-b from-violet-400 to-cyan-400 rounded-r-full" />
              )}
              <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-violet-400' : 'text-slate-500 group-hover:text-slate-300'}`} />
              {!collapsed && <span className="ml-3">{item.label}</span>}
              {collapsed && (
                <div className="tooltip-content absolute left-full ml-2 px-2 py-1 bg-slate-800 text-white text-xs rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all whitespace-nowrap z-50">
                  {item.label}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom menu */}
      <div className="py-4 px-3 space-y-1 border-t border-slate-800/60">
        {bottomItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center ${collapsed ? 'justify-center px-0' : 'px-3'} py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group relative ${
                isActive
                  ? 'bg-gradient-to-r from-violet-500/20 to-cyan-500/10 text-white'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-violet-400' : 'text-slate-500'}`} />
                {item.id === 'notifications' && unreadNotifs > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-0.5">
                    {unreadNotifs}
                  </span>
                )}
              </div>
              {!collapsed && <span className="ml-3">{item.label}</span>}
            </button>
          );
        })}

        {/* User profile */}
        <div className={`mt-3 pt-3 border-t border-slate-800/40 flex items-center ${collapsed ? 'justify-center' : 'px-3'} py-2`}>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center flex-shrink-0 text-white text-sm font-bold">
            J
          </div>
          {!collapsed && (
            <div className="ml-3 flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">John D.</p>
              <p className="text-xs text-slate-500 truncate">Pro Plan</p>
            </div>
          )}
          {!collapsed && (
            <button className="text-slate-500 hover:text-red-400 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

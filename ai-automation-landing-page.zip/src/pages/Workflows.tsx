import { useState } from 'react';
import {
  Search, Plus, Play, Pause, MoreHorizontal, Zap, Clock,
  AlertTriangle, TrendingUp, Bot, ArrowUpRight, ToggleLeft, ToggleRight, Copy, Trash2, Filter
} from 'lucide-react';

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'paused' | 'error';
  agent: string;
  runs: number;
  successRate: number;
  lastRun: string;
  created: string;
  trigger: string;
  nodesCount: number;
}

const workflowsData: Workflow[] = [
  { id: '1', name: 'Lead Qualification Pipeline', description: 'Auto-qualify inbound leads with AI scoring', status: 'active', agent: 'LeadBot', runs: 2341, successRate: 99.2, lastRun: '2 min ago', created: 'Dec 1, 2024', trigger: 'Email', nodesCount: 5 },
  { id: '2', name: 'Customer Onboarding Flow', description: 'End-to-end automated onboarding sequence', status: 'active', agent: 'OnboardAI', runs: 892, successRate: 98.7, lastRun: '5 min ago', created: 'Nov 28, 2024', trigger: 'Webhook', nodesCount: 8 },
  { id: '3', name: 'Invoice Processing', description: 'Extract, validate, and process invoices', status: 'active', agent: 'FinanceBot', runs: 567, successRate: 97.8, lastRun: '12 min ago', created: 'Nov 15, 2024', trigger: 'Email', nodesCount: 6 },
  { id: '4', name: 'Social Media Scheduler', description: 'AI-powered content scheduling across platforms', status: 'error', agent: 'SocialAI', runs: 1234, successRate: 94.5, lastRun: '1 hr ago', created: 'Oct 20, 2024', trigger: 'Schedule', nodesCount: 4 },
  { id: '5', name: 'Support Ticket Router', description: 'Classify and route support tickets to right team', status: 'active', agent: 'SupportBot', runs: 3456, successRate: 99.5, lastRun: '30 sec ago', created: 'Oct 5, 2024', trigger: 'Webhook', nodesCount: 7 },
  { id: '6', name: 'Data Sync — Salesforce', description: 'Bi-directional data sync with Salesforce CRM', status: 'paused', agent: 'SyncAgent', runs: 789, successRate: 99.1, lastRun: '3 days ago', created: 'Sep 12, 2024', trigger: 'Schedule', nodesCount: 3 },
  { id: '7', name: 'Meeting Notes Summarizer', description: 'Transcribe & summarize meeting recordings', status: 'active', agent: 'MeetingAI', runs: 234, successRate: 98.9, lastRun: '1 hr ago', created: 'Dec 3, 2024', trigger: 'Webhook', nodesCount: 5 },
  { id: '8', name: 'Competitor Price Monitor', description: 'Track competitor pricing and alert on changes', status: 'active', agent: 'PriceBot', runs: 1567, successRate: 99.8, lastRun: '15 min ago', created: 'Aug 1, 2024', trigger: 'Schedule', nodesCount: 6 },
];

export default function Workflows({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const [workflows, setWorkflows] = useState(workflowsData);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'paused' | 'error'>('all');
  const [showMenu, setShowMenu] = useState<string | null>(null);

  const filteredWorkflows = workflows.filter(w => {
    const matchesSearch = w.name.toLowerCase().includes(search.toLowerCase()) || w.description.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'all' || w.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const toggleStatus = (id: string) => {
    setWorkflows(prev => prev.map(w =>
      w.id === id ? { ...w, status: w.status === 'active' ? 'paused' as const : 'active' as const } : w
    ));
  };

  const deleteWorkflow = (id: string) => {
    setWorkflows(prev => prev.filter(w => w.id !== id));
    setShowMenu(null);
  };

  const activeCount = workflows.filter(w => w.status === 'active').length;
  const totalRuns = workflows.reduce((sum, w) => sum + w.runs, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Workflows</h1>
          <p className="text-slate-400 text-sm mt-1">
            {activeCount} active · {workflows.length} total · {totalRuns.toLocaleString()} total runs
          </p>
        </div>
        <button
          onClick={() => onNavigate('builder')}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-violet-500/25 transition-all"
        >
          <Plus className="w-4 h-4" /> New Workflow
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search workflows..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900/80 border border-slate-800/60 rounded-xl text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-violet-500/50"
          />
        </div>
        <div className="flex gap-2">
          {(['all', 'active', 'paused', 'error'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-2 rounded-xl text-sm font-medium capitalize transition-colors ${
                statusFilter === s
                  ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30'
                  : 'bg-slate-900/80 text-slate-400 border border-slate-800/60 hover:text-white'
              }`}
            >
              {s === 'all' ? `All (${workflows.length})` : s}
            </button>
          ))}
        </div>
      </div>

      {/* Workflow cards */}
      <div className="grid gap-3">
        {filteredWorkflows.map((workflow) => (
          <div
            key={workflow.id}
            className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5 hover:border-slate-700/60 transition-all group"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4 flex-1">
                {/* Status indicator */}
                <div className={`mt-1 w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  workflow.status === 'active' ? 'bg-emerald-500/10' :
                  workflow.status === 'paused' ? 'bg-amber-500/10' : 'bg-red-500/10'
                }`}>
                  {workflow.status === 'active' && <Zap className="w-5 h-5 text-emerald-400" />}
                  {workflow.status === 'paused' && <Pause className="w-5 h-5 text-amber-400" />}
                  {workflow.status === 'error' && <AlertTriangle className="w-5 h-5 text-red-400" />}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-white font-semibold">{workflow.name}</h3>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      workflow.status === 'active' ? 'text-emerald-400 bg-emerald-400/10' :
                      workflow.status === 'paused' ? 'text-amber-400 bg-amber-400/10' :
                      'text-red-400 bg-red-400/10'
                    }`}>
                      {workflow.status}
                    </span>
                  </div>
                  <p className="text-sm text-slate-500 mt-0.5">{workflow.description}</p>

                  {/* Meta info */}
                  <div className="flex flex-wrap items-center gap-4 mt-3">
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Bot className="w-3.5 h-3.5 text-violet-400" />
                      {workflow.agent}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Play className="w-3.5 h-3.5" />
                      {workflow.runs.toLocaleString()} runs
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">
                      <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                      {workflow.successRate}% success
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Clock className="w-3.5 h-3.5" />
                      {workflow.lastRun}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Filter className="w-3.5 h-3.5" />
                      {workflow.nodesCount} nodes
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 ml-4">
                <button
                  onClick={() => toggleStatus(workflow.id)}
                  className="text-slate-400 hover:text-white transition-colors"
                  title={workflow.status === 'active' ? 'Pause' : 'Activate'}
                >
                  {workflow.status === 'active' ? (
                    <ToggleRight className="w-8 h-8 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-slate-500" />
                  )}
                </button>
                <div className="relative">
                  <button
                    onClick={() => setShowMenu(showMenu === workflow.id ? null : workflow.id)}
                    className="p-2 rounded-lg hover:bg-slate-800/50 text-slate-400 hover:text-white transition-colors"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                  {showMenu === workflow.id && (
                    <div className="absolute right-0 top-full mt-1 w-40 bg-slate-800 border border-slate-700/50 rounded-xl shadow-xl z-20 overflow-hidden">
                      <button onClick={() => { onNavigate('builder'); setShowMenu(null); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-white hover:bg-slate-700/50 transition-colors">
                        <ArrowUpRight className="w-3.5 h-3.5" /> Edit
                      </button>
                      <button onClick={() => {
                        const orig = workflows.find(w => w.id === workflow.id);
                        if (orig) {
                          const dup = { ...orig, id: Date.now().toString(), name: orig.name + ' (Copy)', status: 'paused' as const, runs: 0, lastRun: 'Never' };
                          setWorkflows(prev => [dup, ...prev]);
                        }
                        setShowMenu(null);
                      }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-white hover:bg-slate-700/50 transition-colors">
                         <Copy className="w-3.5 h-3.5" /> Duplicate
                       </button>
                      <button onClick={() => deleteWorkflow(workflow.id)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" /> Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredWorkflows.length === 0 && (
        <div className="text-center py-16">
          <Zap className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-white font-semibold">No workflows found</h3>
          <p className="text-sm text-slate-500 mt-1">Try adjusting your filters or create a new workflow</p>
        </div>
      )}
    </div>
  );
}

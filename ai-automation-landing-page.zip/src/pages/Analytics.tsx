import {
  TrendingUp, ArrowUpRight, ArrowDownRight, Clock, Zap, CheckCircle2, BarChart3
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, LineChart, Line
} from 'recharts';

const weeklyData = [
  { name: 'Week 1', runs: 4560, hours: 120, cost: 45 },
  { name: 'Week 2', runs: 5230, hours: 145, cost: 52 },
  { name: 'Week 3', runs: 6100, hours: 168, cost: 48 },
  { name: 'Week 4', runs: 7840, hours: 210, cost: 55 },
  { name: 'Week 5', runs: 8920, hours: 245, cost: 51 },
  { name: 'Week 6', runs: 9150, hours: 260, cost: 49 },
  { name: 'Week 7', runs: 11200, hours: 312, cost: 53 },
  { name: 'Week 8', runs: 12400, hours: 340, cost: 47 },
];

const agentPerformance = [
  { name: 'LeadBot', tasks: 2341, accuracy: 99.2 },
  { name: 'SupportBot', tasks: 3456, accuracy: 99.5 },
  { name: 'OnboardAI', tasks: 892, accuracy: 98.7 },
  { name: 'FinanceBot', tasks: 567, accuracy: 97.8 },
  { name: 'PriceBot', tasks: 1567, accuracy: 99.8 },
  { name: 'MeetingAI', tasks: 234, accuracy: 98.9 },
];

const pieData = [
  { name: 'Email', value: 35, color: '#8b5cf6' },
  { name: 'CRM', value: 25, color: '#06b6d4' },
  { name: 'Messaging', value: 20, color: '#10b981' },
  { name: 'Database', value: 12, color: '#f59e0b' },
  { name: 'Other', value: 8, color: '#64748b' },
];

const hourlyData = Array.from({ length: 24 }, (_, i) => ({
  hour: `${i}:00`,
  runs: Math.floor(Math.random() * 200 + 50 + (i >= 9 && i <= 17 ? 300 : 0)),
}));

const kpis = [
  { label: 'Total Automations', value: '12,847', change: '+23.5%', up: true, icon: Zap, color: 'from-violet-500 to-purple-600', subtext: 'This month' },
  { label: 'Hours Saved', value: '1,640', change: '+18.2%', up: true, icon: Clock, color: 'from-cyan-500 to-blue-600', subtext: '$82,000 value' },
  { label: 'AI Accuracy', value: '98.8%', change: '+0.5%', up: true, icon: CheckCircle2, color: 'from-emerald-500 to-green-600', subtext: 'Across all agents' },
  { label: 'Cost per Run', value: '$0.004', change: '-12%', up: true, icon: TrendingUp, color: 'from-amber-500 to-orange-600', subtext: 'Avg this month' },
];

export default function Analytics() {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <BarChart3 className="w-7 h-7 text-violet-400" />
          Analytics
        </h1>
        <p className="text-slate-400 text-sm mt-1">Monitor performance, usage, and ROI across all your automations</p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5 hover:border-slate-700/60 transition-all">
              <div className="flex items-start justify-between">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${kpi.color} flex items-center justify-center shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full ${kpi.up ? 'text-emerald-400 bg-emerald-400/10' : 'text-red-400 bg-red-400/10'}`}>
                  {kpi.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {kpi.change}
                </div>
              </div>
              <p className="text-2xl font-bold text-white mt-3">{kpi.value}</p>
              <p className="text-sm text-slate-500 mt-0.5">{kpi.label}</p>
              <p className="text-xs text-slate-600 mt-1">{kpi.subtext}</p>
            </div>
          );
        })}
      </div>

      {/* Main charts */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Growth chart */}
        <div className="xl:col-span-2 bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-semibold">Growth Trend</h3>
              <p className="text-sm text-slate-500">Weekly automation runs & hours saved</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="gradRuns" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradHours" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" stroke="#475569" fontSize={12} />
              <YAxis stroke="#475569" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 13 }} />
              <Area type="monotone" dataKey="runs" stroke="#8b5cf6" fill="url(#gradRuns)" strokeWidth={2} />
              <Area type="monotone" dataKey="hours" stroke="#06b6d4" fill="url(#gradHours)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Distribution pie */}
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-1">Integration Usage</h3>
          <p className="text-sm text-slate-500 mb-4">Distribution by type</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={3}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 13 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 justify-center">
            {pieData.map((entry) => (
              <div key={entry.name} className="flex items-center gap-1.5 text-xs text-slate-400">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                {entry.name} ({entry.value}%)
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Second row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Agent performance */}
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-1">Agent Performance</h3>
          <p className="text-sm text-slate-500 mb-4">Tasks completed by each agent</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={agentPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" stroke="#475569" fontSize={11} />
              <YAxis stroke="#475569" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 13 }} />
              <Bar dataKey="tasks" fill="#8b5cf6" radius={[6, 6, 0, 0]} barSize={36} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Hourly pattern */}
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-1">Daily Activity Pattern</h3>
          <p className="text-sm text-slate-500 mb-4">Automation runs by hour of day</p>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="hour" stroke="#475569" fontSize={10} interval={3} />
              <YAxis stroke="#475569" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 13 }} />
              <Line type="monotone" dataKey="runs" stroke="#06b6d4" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ROI summary */}
      <div className="bg-gradient-to-r from-violet-600/20 via-purple-600/10 to-cyan-600/20 border border-violet-500/20 rounded-2xl p-6">
        <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          ROI Summary — This Month
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Manual Work Eliminated</p>
            <p className="text-2xl font-bold text-white">1,640 hrs</p>
            <p className="text-sm text-emerald-400 mt-1">≈ 41 full-time weeks</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Cost Savings</p>
            <p className="text-2xl font-bold text-white">$82,000</p>
            <p className="text-sm text-emerald-400 mt-1">Based on $50/hr rate</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">SynapseFlow Cost</p>
            <p className="text-2xl font-bold text-white">$149</p>
            <p className="text-sm text-violet-400 mt-1">Pro Plan</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">ROI</p>
            <p className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">550x</p>
            <p className="text-sm text-emerald-400 mt-1">Return on investment</p>
          </div>
        </div>
      </div>
    </div>
  );
}

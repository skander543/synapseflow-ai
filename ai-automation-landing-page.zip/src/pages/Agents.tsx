import { useState, useRef, useEffect } from 'react';
import {
  Bot, Plus, Settings, Activity, TrendingUp, Zap, Brain, MessageSquare,
  Shield, MoreHorizontal, Sparkles, Power, BarChart3, Send, Trash2,
  CheckCircle2, AlertTriangle, Clock
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line
} from 'recharts';
import Modal from '../components/Modal';

interface Agent {
  id: string;
  name: string;
  role: string;
  status: 'online' | 'training' | 'offline';
  model: string;
  tasksCompleted: number;
  accuracy: number;
  avgResponse: string;
  uptime: string;
  skills: string[];
  avatar: string;
  color: string;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
}

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

const initialAgents: Agent[] = [
  { id: '1', name: 'LeadBot', role: 'Lead Qualification Agent', status: 'online', model: 'GPT-4o', tasksCompleted: 12453, accuracy: 99.2, avgResponse: '1.2s', uptime: '99.9%', skills: ['Email Analysis', 'Scoring', 'CRM Updates'], avatar: '🎯', color: 'from-violet-500 to-purple-600', systemPrompt: 'You are a lead qualification specialist. Analyze incoming leads and score them based on buying intent.', temperature: 0.3, maxTokens: 1024 },
  { id: '2', name: 'OnboardAI', role: 'Customer Onboarding Agent', status: 'online', model: 'Claude 3.5', tasksCompleted: 3892, accuracy: 98.7, avgResponse: '2.1s', uptime: '99.8%', skills: ['Personalization', 'Sequencing', 'Follow-ups'], avatar: '🚀', color: 'from-cyan-500 to-blue-600', systemPrompt: 'You are an onboarding specialist. Guide new customers through setup.', temperature: 0.5, maxTokens: 2048 },
  { id: '3', name: 'FinanceBot', role: 'Invoice Processing Agent', status: 'online', model: 'GPT-4o', tasksCompleted: 8567, accuracy: 97.8, avgResponse: '3.4s', uptime: '99.7%', skills: ['OCR', 'Data Extraction', 'Validation'], avatar: '💰', color: 'from-emerald-500 to-green-600', systemPrompt: 'You are a financial document processor. Extract and validate invoice data.', temperature: 0.1, maxTokens: 512 },
  { id: '4', name: 'SocialAI', role: 'Social Media Agent', status: 'training', model: 'GPT-4o Mini', tasksCompleted: 5234, accuracy: 94.5, avgResponse: '0.8s', uptime: '97.2%', skills: ['Content Gen', 'Scheduling', 'Analytics'], avatar: '📱', color: 'from-pink-500 to-rose-600', systemPrompt: 'You are a social media content creator. Generate engaging posts and manage scheduling.', temperature: 0.8, maxTokens: 1024 },
  { id: '5', name: 'SupportBot', role: 'Customer Support Agent', status: 'online', model: 'Claude 3.5', tasksCompleted: 21456, accuracy: 99.5, avgResponse: '0.5s', uptime: '99.9%', skills: ['Classification', 'Routing', 'Resolution'], avatar: '💬', color: 'from-amber-500 to-orange-600', systemPrompt: 'You are a customer support agent. Classify tickets and provide helpful responses.', temperature: 0.4, maxTokens: 2048 },
  { id: '6', name: 'SyncAgent', role: 'Data Synchronization Agent', status: 'offline', model: 'Custom', tasksCompleted: 4789, accuracy: 99.1, avgResponse: '2.1s', uptime: '99.5%', skills: ['Bi-directional Sync', 'Conflict Resolution', 'Mapping'], avatar: '🔄', color: 'from-indigo-500 to-blue-600', systemPrompt: 'You manage data synchronization between systems. Handle conflicts and mapping.', temperature: 0.2, maxTokens: 512 },
];

const agentResponses: Record<string, string[]> = {
  LeadBot: [
    "I've analyzed the incoming lead from john@acme.com. Based on their company size (500+ employees), industry (SaaS), and the inquiry about enterprise pricing, I'm scoring this lead at **92/100** — highly qualified. Recommended action: Route to enterprise sales team immediately.",
    "Lead qualification report for this week:\n- **47 new leads** processed\n- **23 qualified** (score > 70)\n- **12 hot leads** (score > 90)\n- Average response time: 1.1s\n- Top converting source: Website demo request form",
    "I detected a pattern: leads from the fintech vertical have a 3x higher conversion rate this month. Recommend increasing ad spend on fintech channels by 40%.",
  ],
  OnboardAI: [
    "Welcome sequence for new user Sarah M. has been initiated:\n1. ✅ Welcome email sent\n2. ✅ Account provisioned\n3. ⏳ Day 2: Feature walkthrough scheduled\n4. ⏳ Day 5: Check-in email queued\n5. ⏳ Day 14: ROI review scheduled",
    "Onboarding completion rate this week: **94.2%** (up from 89.1%). The new interactive tutorial I suggested has improved step 3 completion by 28%.",
    "I noticed user Mike T. has been stuck on the integration step for 2 days. I've sent a personalized help email with a video tutorial and offered a 1-on-1 setup call.",
  ],
  FinanceBot: [
    "Invoice #INV-2024-0847 processed:\n- **Vendor:** CloudTech Solutions\n- **Amount:** $12,450.00\n- **Due Date:** Jan 15, 2025\n- **Category:** Auto-classified as 'SaaS Subscriptions'\n- **Status:** ✅ Validated & approved for payment",
    "Monthly invoice processing summary:\n- **234 invoices** processed\n- **$1.2M** total value\n- **3 discrepancies** detected and flagged\n- **$4,200** saved by catching a duplicate charge",
    "Alert: I detected an unusual invoice from vendor XYZ Corp for $45,000 — this is 3x their typical billing. Flagged for manual review.",
  ],
  SocialAI: [
    "Here's your content calendar for next week:\n- **Mon:** Product tip thread (Twitter/X)\n- **Tue:** Customer success story (LinkedIn)\n- **Wed:** Behind-the-scenes reel (Instagram)\n- **Thu:** Industry insights carousel (LinkedIn)\n- **Fri:** Fun team photo + weekly wins (All platforms)",
    "Post performance report:\n- Best performing: 'AI Automation Tips' thread — **23.4K impressions**, **892 engagements**\n- LinkedIn company page grew by **+342 followers** this week\n- Optimal posting time identified: Tuesday 10:30 AM EST",
    "I've drafted 5 variations of the product launch announcement. Each is optimized for a different platform's algorithm and character limits. Ready for your review!",
  ],
  SupportBot: [
    "Ticket #4521 resolved:\n- **Issue:** User couldn't connect Salesforce integration\n- **Root cause:** OAuth token expired\n- **Resolution:** Guided user through re-authentication\n- **Time to resolve:** 45 seconds\n- **Customer satisfaction:** ⭐⭐⭐⭐⭐",
    "Support metrics today:\n- **127 tickets** handled\n- **94%** resolved without escalation\n- **Average response time:** 0.5s\n- **CSAT score:** 4.8/5.0\n- **Top issue:** Integration setup questions (34%)",
    "I've identified a recurring issue with the Gmail integration. 12 tickets this week mention the same error. Recommend the engineering team look into the OAuth refresh flow.",
  ],
  SyncAgent: [
    "Sync report — Salesforce ↔ SynapseFlow:\n- **Records synced:** 4,521\n- **Conflicts detected:** 3\n- **Conflicts auto-resolved:** 2 (most recent wins)\n- **1 conflict** flagged for manual review\n- **Sync time:** 2.1 seconds",
    "All systems in sync. Last full sync completed 30 seconds ago. No data discrepancies detected across 14 connected integrations.",
    "Warning: Detected schema change in HubSpot CRM — new field 'lead_score_v2' added. I've automatically mapped it to our internal scoring system. Please review the mapping.",
  ],
};

const generatePerfData = () => Array.from({ length: 7 }, (_, i) => ({
  day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
  tasks: Math.floor(Math.random() * 500 + 200),
  accuracy: Math.floor(Math.random() * 5 + 95),
  responseTime: +(Math.random() * 2 + 0.5).toFixed(1),
}));

export default function Agents() {
  const [agents, setAgents] = useState(initialAgents);
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [chatAgent, setChatAgent] = useState<Agent | null>(null);
  const [configAgent, setConfigAgent] = useState<Agent | null>(null);
  const [analyticsAgent, setAnalyticsAgent] = useState<Agent | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [deploying, setDeploying] = useState(false);
  const [deploySuccess, setDeploySuccess] = useState(false);

  // New agent form
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newModel, setNewModel] = useState('GPT-4o');
  const [newSkills, setNewSkills] = useState('');
  const [newPrompt, setNewPrompt] = useState('');

  // Config form
  const [cfgName, setCfgName] = useState('');
  const [cfgRole, setCfgRole] = useState('');
  const [cfgModel, setCfgModel] = useState('');
  const [cfgPrompt, setCfgPrompt] = useState('');
  const [cfgTemp, setCfgTemp] = useState(50);
  const [cfgMaxTokens, setCfgMaxTokens] = useState(1024);
  const [cfgSaved, setCfgSaved] = useState(false);

  const onlineCount = agents.filter(a => a.status === 'online').length;
  const totalTasks = agents.reduce((sum, a) => sum + a.tasksCompleted, 0);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isTyping]);

  const toggleAgent = (id: string) => {
    setAgents(prev => prev.map(a =>
      a.id === id ? { ...a, status: a.status === 'online' ? 'offline' as const : 'online' as const } : a
    ));
  };

  const deleteAgent = (id: string) => {
    setAgents(prev => prev.filter(a => a.id !== id));
    setDeleteConfirm(null);
    setSelectedAgent(null);
  };

  const deployAgent = () => {
    if (!newName.trim()) return;
    setDeploying(true);
    setTimeout(() => {
      const avatars = ['🧠', '⚡', '🔮', '🎨', '📈', '🛡️', '🔥', '💎', '🌟', '🦾'];
      const colors = ['from-violet-500 to-purple-600', 'from-cyan-500 to-blue-600', 'from-emerald-500 to-green-600', 'from-pink-500 to-rose-600', 'from-amber-500 to-orange-600', 'from-indigo-500 to-blue-600'];
      const newAgent: Agent = {
        id: Date.now().toString(),
        name: newName,
        role: newRole || 'Custom AI Agent',
        status: 'online',
        model: newModel,
        tasksCompleted: 0,
        accuracy: 100,
        avgResponse: '0.0s',
        uptime: '100%',
        skills: newSkills ? newSkills.split(',').map(s => s.trim()) : ['General'],
        avatar: avatars[Math.floor(Math.random() * avatars.length)],
        color: colors[Math.floor(Math.random() * colors.length)],
        systemPrompt: newPrompt || 'You are a helpful AI assistant.',
        temperature: 0.5,
        maxTokens: 1024,
      };
      setAgents(prev => [newAgent, ...prev]);
      setDeploying(false);
      setDeploySuccess(true);
      setTimeout(() => {
        setDeploySuccess(false);
        setShowCreate(false);
        setNewName(''); setNewRole(''); setNewSkills(''); setNewPrompt(''); setNewModel('GPT-4o');
      }, 1500);
    }, 2000);
  };

  const openChat = (agent: Agent) => {
    setChatAgent(agent);
    setChatMessages([
      { role: 'system', content: `Chat with ${agent.name} — ${agent.role}`, timestamp: new Date() },
      { role: 'assistant', content: `Hello! I'm ${agent.name}, your ${agent.role.toLowerCase()}. I'm running on ${agent.model} and ready to help. What would you like to know?`, timestamp: new Date() },
    ]);
  };

  const sendMessage = () => {
    if (!chatInput.trim() || !chatAgent) return;
    const userMsg: ChatMessage = { role: 'user', content: chatInput, timestamp: new Date() };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsTyping(true);

    setTimeout(() => {
      const responses = agentResponses[chatAgent.name] || [
        `I've processed your request. As ${chatAgent.name}, I can help you with ${chatAgent.skills.join(', ')}. Let me analyze this further and provide a detailed response.`,
        `Based on my analysis using ${chatAgent.model}, here's what I found: The data shows positive trends across all metrics. I recommend continuing the current strategy with minor optimizations.`,
        `Task completed successfully! I've updated the relevant systems and logged this interaction. Is there anything else you'd like me to help with?`,
      ];
      const response = responses[Math.floor(Math.random() * responses.length)];
      setChatMessages(prev => [...prev, { role: 'assistant', content: response, timestamp: new Date() }]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const openConfig = (agent: Agent) => {
    setConfigAgent(agent);
    setCfgName(agent.name);
    setCfgRole(agent.role);
    setCfgModel(agent.model);
    setCfgPrompt(agent.systemPrompt);
    setCfgTemp(agent.temperature * 100);
    setCfgMaxTokens(agent.maxTokens);
    setCfgSaved(false);
  };

  const saveConfig = () => {
    if (!configAgent) return;
    setAgents(prev => prev.map(a => a.id === configAgent.id ? {
      ...a,
      name: cfgName,
      role: cfgRole,
      model: cfgModel,
      systemPrompt: cfgPrompt,
      temperature: cfgTemp / 100,
      maxTokens: cfgMaxTokens,
    } : a));
    setCfgSaved(true);
    setTimeout(() => { setCfgSaved(false); setConfigAgent(null); }, 1200);
  };

  const perfData = generatePerfData();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Bot className="w-7 h-7 text-violet-400" />
            AI Agents
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            {onlineCount} online · {agents.length} total · {totalTasks.toLocaleString()} tasks completed
          </p>
        </div>
        <button
          onClick={() => setShowCreate(!showCreate)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-violet-500/25 transition-all"
        >
          <Plus className="w-4 h-4" /> Deploy Agent
        </button>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-xl p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs font-medium mb-1">
            <Bot className="w-3.5 h-3.5" /> Total Agents
          </div>
          <p className="text-xl font-bold text-white">{agents.length}</p>
        </div>
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-xl p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs font-medium mb-1">
            <Activity className="w-3.5 h-3.5 text-emerald-400" /> Online
          </div>
          <p className="text-xl font-bold text-emerald-400">{onlineCount}</p>
        </div>
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-xl p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs font-medium mb-1">
            <Zap className="w-3.5 h-3.5 text-violet-400" /> Tasks Today
          </div>
          <p className="text-xl font-bold text-white">1,847</p>
        </div>
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-xl p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs font-medium mb-1">
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" /> Avg Accuracy
          </div>
          <p className="text-xl font-bold text-white">
            {agents.length > 0 ? (agents.reduce((s, a) => s + a.accuracy, 0) / agents.length).toFixed(1) : 0}%
          </p>
        </div>
      </div>

      {/* Create agent panel */}
      {showCreate && (
        <div className="bg-slate-900/80 border border-violet-500/30 rounded-2xl p-6 animate-fade-in">
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-violet-400" />
            Deploy New AI Agent
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Agent Name *</label>
              <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g., MarketingBot" className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Role</label>
              <input value={newRole} onChange={e => setNewRole(e.target.value)} placeholder="e.g., Marketing Automation Agent" className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">AI Model</label>
              <select value={newModel} onChange={e => setNewModel(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                <option>GPT-4o</option>
                <option>GPT-4o Mini</option>
                <option>Claude 3.5 Sonnet</option>
                <option>Llama 3.1 70B</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Skills (comma separated)</label>
              <input value={newSkills} onChange={e => setNewSkills(e.target.value)} placeholder="e.g., Email, Analytics, Content" className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
            </div>
          </div>
          <div className="mt-4">
            <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">System Prompt</label>
            <textarea rows={3} value={newPrompt} onChange={e => setNewPrompt(e.target.value)} placeholder="Define the agent's behavior and capabilities..." className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50 resize-none" />
          </div>
          <div className="flex gap-3 mt-4">
            <button
              onClick={deployAgent}
              disabled={!newName.trim() || deploying}
              className={`px-4 py-2 text-sm font-semibold rounded-xl transition-all flex items-center gap-2 ${
                deploySuccess ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                deploying ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' :
                !newName.trim() ? 'bg-slate-800/50 text-slate-500 cursor-not-allowed' :
                'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg'
              }`}
            >
              {deploySuccess ? <><CheckCircle2 className="w-4 h-4" /> Deployed!</> :
               deploying ? <><div className="w-4 h-4 border-2 border-violet-300 border-t-transparent rounded-full animate-spin" /> Deploying...</> :
               <><Sparkles className="w-4 h-4" /> Deploy Agent</>}
            </button>
            <button onClick={() => setShowCreate(false)} className="px-4 py-2 bg-slate-800/80 text-slate-300 text-sm font-medium rounded-xl hover:bg-slate-700/80 transition-all border border-slate-700/50">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Agent cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {agents.map((agent) => (
          <div
            key={agent.id}
            className={`bg-slate-900/80 border rounded-2xl p-5 transition-all hover:shadow-lg ${
              selectedAgent === agent.id ? 'border-violet-500/40 shadow-violet-500/5' : 'border-slate-800/60 hover:border-slate-700/60'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${agent.color} flex items-center justify-center text-2xl shadow-lg`}>
                  {agent.avatar}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-white font-bold">{agent.name}</h3>
                    <span className={`flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${
                      agent.status === 'online' ? 'text-emerald-400 bg-emerald-400/10' :
                      agent.status === 'training' ? 'text-amber-400 bg-amber-400/10' :
                      'text-slate-400 bg-slate-400/10'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        agent.status === 'online' ? 'bg-emerald-400 animate-pulse' :
                        agent.status === 'training' ? 'bg-amber-400 animate-pulse' :
                        'bg-slate-500'
                      }`} />
                      {agent.status}
                    </span>
                  </div>
                  <p className="text-sm text-slate-500">{agent.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => toggleAgent(agent.id)}
                  className="p-1.5 rounded-lg hover:bg-slate-800/50 text-slate-400 hover:text-white transition-colors"
                  title={agent.status === 'online' ? 'Turn off' : 'Turn on'}
                >
                  <Power className={`w-4 h-4 ${agent.status === 'online' ? 'text-emerald-400' : ''}`} />
                </button>
                <button
                  onClick={() => setSelectedAgent(selectedAgent === agent.id ? null : agent.id)}
                  className="p-1.5 rounded-lg hover:bg-slate-800/50 text-slate-400 hover:text-white transition-colors"
                >
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-4 gap-3 mt-4">
              <div className="text-center p-2 bg-slate-800/30 rounded-lg">
                <p className="text-xs text-slate-500 mb-0.5">Tasks</p>
                <p className="text-sm font-bold text-white">{agent.tasksCompleted > 1000 ? (agent.tasksCompleted / 1000).toFixed(1) + 'k' : agent.tasksCompleted}</p>
              </div>
              <div className="text-center p-2 bg-slate-800/30 rounded-lg">
                <p className="text-xs text-slate-500 mb-0.5">Accuracy</p>
                <p className="text-sm font-bold text-emerald-400">{agent.accuracy}%</p>
              </div>
              <div className="text-center p-2 bg-slate-800/30 rounded-lg">
                <p className="text-xs text-slate-500 mb-0.5">Speed</p>
                <p className="text-sm font-bold text-cyan-400">{agent.avgResponse}</p>
              </div>
              <div className="text-center p-2 bg-slate-800/30 rounded-lg">
                <p className="text-xs text-slate-500 mb-0.5">Uptime</p>
                <p className="text-sm font-bold text-violet-400">{agent.uptime}</p>
              </div>
            </div>

            {/* Skills */}
            <div className="flex flex-wrap gap-1.5 mt-3">
              {agent.skills.map((skill) => (
                <span key={skill} className="px-2 py-1 text-xs text-slate-400 bg-slate-800/50 rounded-lg border border-slate-700/30">
                  {skill}
                </span>
              ))}
              <span className="px-2 py-1 text-xs text-slate-500 bg-slate-800/30 rounded-lg">
                <Brain className="w-3 h-3 inline mr-1" />{agent.model}
              </span>
            </div>

            {/* Expanded details */}
            {selectedAgent === agent.id && (
              <div className="mt-4 pt-4 border-t border-slate-800/60 animate-fade-in space-y-3">
                <div className="flex gap-2">
                  <button onClick={() => openConfig(agent)} className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-sm text-white bg-violet-500/20 border border-violet-500/30 hover:bg-violet-500/30 transition-colors">
                    <Settings className="w-4 h-4" /> Configure
                  </button>
                  <button onClick={() => setAnalyticsAgent(agent)} className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-sm text-white bg-cyan-500/20 border border-cyan-500/30 hover:bg-cyan-500/30 transition-colors">
                    <BarChart3 className="w-4 h-4" /> Analytics
                  </button>
                  <button onClick={() => openChat(agent)} className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-sm text-white bg-emerald-500/20 border border-emerald-500/30 hover:bg-emerald-500/30 transition-colors">
                    <MessageSquare className="w-4 h-4" /> Chat
                  </button>
                </div>
                <button
                  onClick={() => setDeleteConfirm(agent.id)}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-sm text-red-400 bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 transition-colors"
                >
                  <Trash2 className="w-4 h-4" /> Delete Agent
                </button>
                <div className="p-3 bg-slate-800/30 rounded-xl">
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <Shield className="w-3 h-3" /> Security Level
                  </div>
                  <div className="w-full bg-slate-700/50 rounded-full h-2">
                    <div className="h-2 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-full" style={{ width: '92%' }} />
                  </div>
                  <p className="text-xs text-slate-400 mt-1">Enterprise-grade · SOC2 Compliant</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Chat Modal */}
      <Modal open={!!chatAgent} onClose={() => setChatAgent(null)} title={chatAgent ? `Chat with ${chatAgent.name}` : ''} size="lg">
        {chatAgent && (
          <div className="flex flex-col h-[60vh]">
            {/* Chat messages */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-2">
              {chatMessages.filter(m => m.role !== 'system').map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    msg.role === 'user'
                      ? 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white'
                      : 'bg-slate-800/80 border border-slate-700/50 text-slate-200'
                  }`}>
                    {msg.role === 'assistant' && (
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-lg">{chatAgent.avatar}</span>
                        <span className="text-xs font-semibold text-violet-400">{chatAgent.name}</span>
                      </div>
                    )}
                    <div className="text-sm whitespace-pre-wrap">{msg.content}</div>
                    <p className="text-[10px] mt-1.5 opacity-50">
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start animate-slide-up">
                  <div className="bg-slate-800/80 border border-slate-700/50 rounded-2xl px-4 py-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-lg">{chatAgent.avatar}</span>
                      <span className="text-xs font-semibold text-violet-400">{chatAgent.name}</span>
                    </div>
                    <div className="flex gap-1 animate-typing">
                      <span className="w-2 h-2 bg-slate-500 rounded-full" />
                      <span className="w-2 h-2 bg-slate-500 rounded-full" />
                      <span className="w-2 h-2 bg-slate-500 rounded-full" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Quick prompts */}
            <div className="flex gap-2 mt-3 overflow-x-auto pb-2">
              {['Show me a status report', 'What are your metrics?', 'Any issues to flag?'].map(q => (
                <button
                  key={q}
                  onClick={() => { setChatInput(q); }}
                  className="px-3 py-1.5 text-xs text-slate-400 bg-slate-800/50 border border-slate-700/30 rounded-full hover:text-white hover:border-violet-500/30 transition-colors whitespace-nowrap"
                >
                  {q}
                </button>
              ))}
            </div>

            {/* Input */}
            <div className="flex gap-2 mt-2">
              <input
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage()}
                placeholder={`Message ${chatAgent.name}...`}
                className="flex-1 px-4 py-3 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50"
              />
              <button
                onClick={sendMessage}
                disabled={!chatInput.trim()}
                className="px-4 py-3 bg-gradient-to-r from-violet-500 to-cyan-500 text-white rounded-xl hover:shadow-lg hover:shadow-violet-500/25 transition-all disabled:opacity-30"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Configure Modal */}
      <Modal open={!!configAgent} onClose={() => setConfigAgent(null)} title={`Configure ${configAgent?.name || ''}`} size="lg">
        {configAgent && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Agent Name</label>
                <input value={cfgName} onChange={e => setCfgName(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
              </div>
              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Role</label>
                <input value={cfgRole} onChange={e => setCfgRole(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
              </div>
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">AI Model</label>
              <select value={cfgModel} onChange={e => setCfgModel(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                <option>GPT-4o</option>
                <option>GPT-4o Mini</option>
                <option>Claude 3.5 Sonnet</option>
                <option>Llama 3.1 70B</option>
                <option>Custom</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">System Prompt</label>
              <textarea rows={4} value={cfgPrompt} onChange={e => setCfgPrompt(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50 resize-none font-mono" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Temperature: {(cfgTemp / 100).toFixed(2)}</label>
                <input type="range" min="0" max="100" value={cfgTemp} onChange={e => setCfgTemp(+e.target.value)} className="w-full mt-2 accent-violet-500" />
                <div className="flex justify-between text-xs text-slate-500 mt-1"><span>Precise</span><span>Creative</span></div>
              </div>
              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Max Tokens</label>
                <select value={cfgMaxTokens} onChange={e => setCfgMaxTokens(+e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                  <option value={256}>256</option>
                  <option value={512}>512</option>
                  <option value={1024}>1,024</option>
                  <option value={2048}>2,048</option>
                  <option value={4096}>4,096</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 pt-3 border-t border-slate-800/60">
              <button
                onClick={saveConfig}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  cfgSaved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                  'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg hover:shadow-violet-500/25'
                }`}
              >
                {cfgSaved ? <><CheckCircle2 className="w-4 h-4" /> Saved!</> : <><Settings className="w-4 h-4" /> Save Configuration</>}
              </button>
              <button onClick={() => setConfigAgent(null)} className="px-4 py-2.5 bg-slate-800/80 text-slate-300 text-sm font-medium rounded-xl hover:bg-slate-700/80 transition-all border border-slate-700/50">
                Cancel
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Analytics Modal */}
      <Modal open={!!analyticsAgent} onClose={() => setAnalyticsAgent(null)} title={`${analyticsAgent?.name || ''} Analytics`} size="xl">
        {analyticsAgent && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-800/30 rounded-xl text-center">
                <p className="text-xs text-slate-500">Total Tasks</p>
                <p className="text-xl font-bold text-white">{analyticsAgent.tasksCompleted.toLocaleString()}</p>
              </div>
              <div className="p-3 bg-slate-800/30 rounded-xl text-center">
                <p className="text-xs text-slate-500">Accuracy</p>
                <p className="text-xl font-bold text-emerald-400">{analyticsAgent.accuracy}%</p>
              </div>
              <div className="p-3 bg-slate-800/30 rounded-xl text-center">
                <p className="text-xs text-slate-500">Avg Response</p>
                <p className="text-xl font-bold text-cyan-400">{analyticsAgent.avgResponse}</p>
              </div>
              <div className="p-3 bg-slate-800/30 rounded-xl text-center">
                <p className="text-xs text-slate-500">Uptime</p>
                <p className="text-xl font-bold text-violet-400">{analyticsAgent.uptime}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-800/30 rounded-xl p-4">
                <h4 className="text-white font-semibold text-sm mb-3">Tasks Completed (7 days)</h4>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={perfData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="day" stroke="#475569" fontSize={11} />
                    <YAxis stroke="#475569" fontSize={11} />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 12 }} />
                    <Bar dataKey="tasks" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-slate-800/30 rounded-xl p-4">
                <h4 className="text-white font-semibold text-sm mb-3">Response Time (ms)</h4>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={perfData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="day" stroke="#475569" fontSize={11} />
                    <YAxis stroke="#475569" fontSize={11} />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 12 }} />
                    <Line type="monotone" dataKey="responseTime" stroke="#06b6d4" strokeWidth={2} dot={{ fill: '#06b6d4' }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-slate-800/30 rounded-xl p-4">
              <h4 className="text-white font-semibold text-sm mb-3">Recent Activity Log</h4>
              <div className="space-y-2">
                {[
                  { time: '2 min ago', action: 'Processed lead qualification', status: 'success' },
                  { time: '5 min ago', action: 'Updated CRM record #4521', status: 'success' },
                  { time: '8 min ago', action: 'Classified incoming ticket', status: 'success' },
                  { time: '12 min ago', action: 'API rate limit encountered', status: 'warning' },
                  { time: '15 min ago', action: 'Completed batch processing (234 items)', status: 'success' },
                ].map((log, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-slate-700/30 last:border-0">
                    <div className="flex items-center gap-2">
                      {log.status === 'success' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
                      <span className="text-sm text-slate-300">{log.action}</span>
                    </div>
                    <span className="text-xs text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3" />{log.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal open={!!deleteConfirm} onClose={() => setDeleteConfirm(null)} title="Delete Agent" size="sm">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-8 h-8 text-red-400" />
          </div>
          <p className="text-slate-300">Are you sure you want to delete this agent? This action cannot be undone.</p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => deleteConfirm && deleteAgent(deleteConfirm)} className="px-5 py-2.5 bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl text-sm font-semibold hover:bg-red-500/30 transition-colors">
              Yes, Delete
            </button>
            <button onClick={() => setDeleteConfirm(null)} className="px-5 py-2.5 bg-slate-800/80 text-slate-300 text-sm font-medium rounded-xl hover:bg-slate-700/80 transition-all border border-slate-700/50">
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

import { useState } from 'react';
import {
  User, Bell, Shield, CreditCard, Key, Globe, Moon, Sun,
  Save, CheckCircle2, ChevronRight, Copy, Eye, EyeOff, Lock,
  Monitor, Smartphone, LogOut, AlertTriangle, Plus, Trash2
} from 'lucide-react';
import Modal from '../components/Modal';

const tabs = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'billing', label: 'Billing', icon: CreditCard },
  { id: 'api', label: 'API Keys', icon: Key },
];

interface ApiKeyType {
  id: string;
  name: string;
  key: string;
  created: string;
  lastUsed: string;
  active: boolean;
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');
  const [saved, setSaved] = useState(false);
  const [darkMode, setDarkMode] = useState(true);

  // Profile
  const [firstName, setFirstName] = useState('John');
  const [lastName, setLastName] = useState('Doe');
  const [email, setEmail] = useState('john@company.com');
  const [company, setCompany] = useState('Acme Corp');
  const [timezone, setTimezone] = useState('America/New_York (EST)');

  // Notifications
  const [notifs, setNotifs] = useState([
    { id: 'failures', title: 'Workflow Failures', desc: 'Get notified when a workflow fails', enabled: true },
    { id: 'daily', title: 'Daily Summary', desc: 'Receive a daily digest of automation activity', enabled: true },
    { id: 'agent', title: 'Agent Status Changes', desc: 'Alert when an agent goes offline', enabled: true },
    { id: 'features', title: 'New Features', desc: 'Product updates and new feature announcements', enabled: false },
    { id: 'weekly', title: 'Weekly Report', desc: 'Weekly performance and ROI report', enabled: true },
    { id: 'usage', title: 'Usage Alerts', desc: 'Alert when approaching plan limits', enabled: true },
  ]);

  // Security modals
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [show2FAModal, setShow2FAModal] = useState(false);
  const [showSessionsModal, setShowSessionsModal] = useState(false);
  const [showLoginHistory, setShowLoginHistory] = useState(false);
  const [twoFAEnabled, setTwoFAEnabled] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPw, setShowNewPw] = useState(false);
  const [passwordSaved, setPasswordSaved] = useState(false);

  // API Keys
  const [apiKeys, setApiKeys] = useState<ApiKeyType[]>([
    { id: '1', name: 'Production Key', key: 'sf_live_a8k2m4n6p8r0t2v4x6z8b0d2f4h6j8k7x9', created: 'Dec 1, 2024', lastUsed: '2 min ago', active: true },
    { id: '2', name: 'Test Key', key: 'sf_test_q1w3e5r7t9y1u3i5o7p9a1s3d5f7g9h2m2p4', created: 'Nov 28, 2024', lastUsed: '1 hr ago', active: true },
  ]);
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [newKeyName, setNewKeyName] = useState('');
  const [revealedKeys, setRevealedKeys] = useState<Set<string>>(new Set());
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);

  // Billing
  const [showUpgrade, setShowUpgrade] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const toggleNotif = (id: string) => {
    setNotifs(prev => prev.map(n => n.id === id ? { ...n, enabled: !n.enabled } : n));
  };

  const changePassword = () => {
    if (newPassword !== confirmPassword || !currentPassword) return;
    setPasswordSaved(true);
    setTimeout(() => {
      setPasswordSaved(false);
      setShowPasswordModal(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    }, 1500);
  };

  const generateApiKey = () => {
    if (!newKeyName.trim()) return;
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    const key = 'sf_live_' + Array.from({ length: 32 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    const newKey: ApiKeyType = {
      id: Date.now().toString(),
      name: newKeyName,
      key,
      created: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      lastUsed: 'Never',
      active: true,
    };
    setApiKeys(prev => [...prev, newKey]);
    setGeneratedKey(key);
    setNewKeyName('');
  };

  const copyKey = (key: string, id: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const toggleRevealKey = (id: string) => {
    setRevealedKeys(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const deleteApiKey = (id: string) => {
    setApiKeys(prev => prev.filter(k => k.id !== id));
  };

  const maskKey = (key: string) => key.slice(0, 8) + '••••••••••••••••••••' + key.slice(-4);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400 text-sm mt-1">Manage your account and preferences</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Tabs sidebar */}
        <div className="lg:w-56 flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-violet-500/20 text-white border border-violet-500/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 bg-slate-900/80 border border-slate-800/60 rounded-2xl p-6">
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <h2 className="text-lg font-semibold text-white">Profile Settings</h2>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center text-white text-2xl font-bold">
                  {firstName[0]}{lastName[0]}
                </div>
                <div>
                  <button className="px-3 py-1.5 text-sm text-violet-400 bg-violet-500/10 border border-violet-500/30 rounded-lg hover:bg-violet-500/20 transition-colors">
                    Change Avatar
                  </button>
                  <p className="text-xs text-slate-500 mt-1">PNG, JPG up to 5MB</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">First Name</label>
                  <input value={firstName} onChange={e => setFirstName(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
                </div>
                <div>
                  <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Last Name</label>
                  <input value={lastName} onChange={e => setLastName(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
                </div>
                <div>
                  <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Email</label>
                  <input value={email} onChange={e => setEmail(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
                </div>
                <div>
                  <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Company</label>
                  <input value={company} onChange={e => setCompany(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Timezone</label>
                <select value={timezone} onChange={e => setTimezone(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                  <option>America/New_York (EST)</option>
                  <option>America/Los_Angeles (PST)</option>
                  <option>America/Chicago (CST)</option>
                  <option>Europe/London (GMT)</option>
                  <option>Europe/Berlin (CET)</option>
                  <option>Asia/Tokyo (JST)</option>
                  <option>Asia/Shanghai (CST)</option>
                  <option>Australia/Sydney (AEST)</option>
                </select>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
                <div className="flex items-center gap-3">
                  {darkMode ? <Moon className="w-5 h-5 text-violet-400" /> : <Sun className="w-5 h-5 text-amber-400" />}
                  <div>
                    <p className="text-sm text-white font-medium">Dark Mode</p>
                    <p className="text-xs text-slate-500">Toggle dark/light theme</p>
                  </div>
                </div>
                <button
                  onClick={() => setDarkMode(!darkMode)}
                  className={`w-11 h-6 rounded-full transition-colors flex items-center px-0.5 ${darkMode ? 'bg-violet-500' : 'bg-slate-600'}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${darkMode ? 'translate-x-5' : ''}`} />
                </button>
              </div>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <h2 className="text-lg font-semibold text-white">Notification Preferences</h2>
              {notifs.map((notif) => (
                <div key={notif.id} className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
                  <div>
                    <p className="text-sm text-white font-medium">{notif.title}</p>
                    <p className="text-xs text-slate-500">{notif.desc}</p>
                  </div>
                  <button
                    onClick={() => toggleNotif(notif.id)}
                    className={`w-11 h-6 rounded-full transition-colors flex items-center px-0.5 ${notif.enabled ? 'bg-violet-500' : 'bg-slate-600'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white transition-transform ${notif.enabled ? 'translate-x-5' : ''}`} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-6">
              <h2 className="text-lg font-semibold text-white">Security</h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Lock className="w-5 h-5 text-slate-400" />
                    <div><p className="text-sm text-white font-medium">Change Password</p><p className="text-xs text-slate-500">Update your account password</p></div>
                  </div>
                  <button onClick={() => setShowPasswordModal(true)} className="flex items-center gap-1 text-sm text-violet-400 hover:text-violet-300 font-medium">Update <ChevronRight className="w-3.5 h-3.5" /></button>
                </div>
                <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-slate-400" />
                    <div><p className="text-sm text-white font-medium">Two-Factor Auth</p><p className="text-xs text-slate-500">{twoFAEnabled ? 'Enabled — using authenticator app' : 'Add an extra layer of security'}</p></div>
                  </div>
                  <button onClick={() => setShow2FAModal(true)} className={`flex items-center gap-1 text-sm font-medium ${twoFAEnabled ? 'text-emerald-400' : 'text-violet-400 hover:text-violet-300'}`}>
                    {twoFAEnabled ? <><CheckCircle2 className="w-3.5 h-3.5" /> Enabled</> : <>Enable <ChevronRight className="w-3.5 h-3.5" /></>}
                  </button>
                </div>
                <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Monitor className="w-5 h-5 text-slate-400" />
                    <div><p className="text-sm text-white font-medium">Active Sessions</p><p className="text-xs text-slate-500">3 active sessions across devices</p></div>
                  </div>
                  <button onClick={() => setShowSessionsModal(true)} className="flex items-center gap-1 text-sm text-violet-400 hover:text-violet-300 font-medium">Manage <ChevronRight className="w-3.5 h-3.5" /></button>
                </div>
                <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Globe className="w-5 h-5 text-slate-400" />
                    <div><p className="text-sm text-white font-medium">Login History</p><p className="text-xs text-slate-500">View recent sign-in activity</p></div>
                  </div>
                  <button onClick={() => setShowLoginHistory(true)} className="flex items-center gap-1 text-sm text-violet-400 hover:text-violet-300 font-medium">View <ChevronRight className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'billing' && (
            <div className="space-y-6">
              <h2 className="text-lg font-semibold text-white">Billing</h2>
              <div className="p-4 bg-gradient-to-r from-violet-500/20 to-cyan-500/10 border border-violet-500/30 rounded-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-400">Current Plan</p>
                    <p className="text-xl font-bold text-white mt-1">Pro Plan — $149/mo</p>
                    <p className="text-xs text-slate-500 mt-1">Renews Jan 15, 2025</p>
                  </div>
                  <button onClick={() => setShowUpgrade(true)} className="px-4 py-2 bg-violet-500/20 text-violet-300 text-sm font-medium rounded-xl border border-violet-500/30 hover:bg-violet-500/30 transition-colors">
                    Upgrade
                  </button>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
                  <div className="flex items-center gap-3">
                    <CreditCard className="w-5 h-5 text-slate-400" />
                    <div>
                      <p className="text-sm text-white font-medium">•••• •••• •••• 4242</p>
                      <p className="text-xs text-slate-500">Visa · Expires 12/26</p>
                    </div>
                  </div>
                  <button className="text-sm text-violet-400 hover:text-violet-300 font-medium">Update</button>
                </div>
              </div>
              <div>
                <h3 className="text-sm font-medium text-slate-400 mb-3">Usage This Period</h3>
                <div className="space-y-3">
                  {[
                    { label: 'Automation Runs', used: 12847, total: 50000 },
                    { label: 'AI Processing', used: 8240, total: 25000 },
                    { label: 'Active Agents', used: 5, total: 10 },
                  ].map(u => (
                    <div key={u.label}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-400">{u.label}</span>
                        <span className="text-white font-medium">{u.used.toLocaleString()} / {u.total.toLocaleString()}</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-2">
                        <div className="h-2 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-full transition-all" style={{ width: `${(u.used / u.total) * 100}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'api' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-white">API Keys</h2>
                <button onClick={() => { setShowKeyModal(true); setGeneratedKey(null); }} className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg transition-all">
                  <Plus className="w-4 h-4" /> New Key
                </button>
              </div>
              <div className="space-y-3">
                {apiKeys.map(k => (
                  <div key={k.id} className="p-4 bg-slate-800/30 rounded-xl">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="text-sm text-white font-medium">{k.name}</p>
                        <p className="text-xs text-slate-500">Created {k.created} · Last used {k.lastUsed}</p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${k.active ? 'text-emerald-400 bg-emerald-400/10' : 'text-red-400 bg-red-400/10'}`}>
                        {k.active ? 'Active' : 'Revoked'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-3 py-2 bg-slate-900/80 rounded-lg text-sm text-slate-400 font-mono truncate">
                        {revealedKeys.has(k.id) ? k.key : maskKey(k.key)}
                      </code>
                      <button onClick={() => toggleRevealKey(k.id)} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/50 transition-colors">
                        {revealedKeys.has(k.id) ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                      <button onClick={() => copyKey(k.key, k.id)} className={`px-3 py-2 text-sm rounded-lg transition-colors ${copiedKey === k.id ? 'text-emerald-400 bg-emerald-400/10' : 'text-violet-400 bg-violet-500/10 hover:bg-violet-500/20'}`}>
                        {copiedKey === k.id ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <button onClick={() => deleteApiKey(k.id)} className="p-2 text-slate-400 hover:text-red-400 rounded-lg hover:bg-red-500/10 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-4 bg-slate-800/30 rounded-xl">
                <h3 className="text-sm text-white font-medium mb-2 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-violet-400" /> Webhook Endpoint
                </h3>
                <code className="block px-3 py-2 bg-slate-900/80 rounded-lg text-sm text-cyan-400 font-mono">
                  https://api.synapseflow.ai/v1/webhooks/your-id
                </code>
              </div>
            </div>
          )}

          {/* Save button */}
          <div className="mt-8 pt-6 border-t border-slate-800/60 flex justify-end">
            <button
              onClick={handleSave}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                saved
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg hover:shadow-violet-500/25'
              }`}
            >
              {saved ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {saved ? 'Changes Saved!' : 'Save Changes'}
            </button>
          </div>
        </div>
      </div>

      {/* Password Change Modal */}
      <Modal open={showPasswordModal} onClose={() => setShowPasswordModal(false)} title="Change Password" size="sm">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Current Password</label>
            <input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
          </div>
          <div>
            <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">New Password</label>
            <div className="relative">
              <input type={showNewPw ? 'text' : 'password'} value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50 pr-10" />
              <button onClick={() => setShowNewPw(!showNewPw)} className="absolute right-3 top-1/2 text-slate-500 hover:text-white">
                {showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <div>
            <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Confirm New Password</label>
            <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
            {confirmPassword && newPassword !== confirmPassword && (
              <p className="text-xs text-red-400 mt-1">Passwords don't match</p>
            )}
          </div>
          {newPassword && (
            <div className="space-y-1">
              <p className="text-xs text-slate-500 font-medium">Password strength:</p>
              <div className="w-full bg-slate-700/50 rounded-full h-1.5">
                <div className={`h-1.5 rounded-full transition-all ${
                  newPassword.length >= 12 ? 'w-full bg-emerald-500' : newPassword.length >= 8 ? 'w-2/3 bg-amber-500' : 'w-1/3 bg-red-500'
                }`} />
              </div>
              <p className={`text-xs ${newPassword.length >= 12 ? 'text-emerald-400' : newPassword.length >= 8 ? 'text-amber-400' : 'text-red-400'}`}>
                {newPassword.length >= 12 ? 'Strong' : newPassword.length >= 8 ? 'Medium' : 'Weak — use at least 8 characters'}
              </p>
            </div>
          )}
          <button
            onClick={changePassword}
            disabled={!currentPassword || !newPassword || newPassword !== confirmPassword}
            className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
              passwordSaved ? 'bg-emerald-500/20 text-emerald-400' :
              !currentPassword || !newPassword || newPassword !== confirmPassword ? 'bg-slate-800/50 text-slate-500 cursor-not-allowed' :
              'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg'
            }`}
          >
            {passwordSaved ? <><CheckCircle2 className="w-4 h-4" /> Password Updated!</> : 'Update Password'}
          </button>
        </div>
      </Modal>

      {/* 2FA Modal */}
      <Modal open={show2FAModal} onClose={() => setShow2FAModal(false)} title="Two-Factor Authentication" size="sm">
        <div className="space-y-4 text-center">
          {!twoFAEnabled ? (
            <>
              <div className="w-32 h-32 mx-auto bg-white rounded-xl flex items-center justify-center">
                <div className="grid grid-cols-5 gap-0.5 w-24">
                  {Array.from({ length: 25 }, (_, i) => (
                    <div key={i} className={`w-4 h-4 ${Math.random() > 0.4 ? 'bg-black' : 'bg-white'} rounded-[1px]`} />
                  ))}
                </div>
              </div>
              <p className="text-sm text-slate-400">Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)</p>
              <code className="block px-3 py-2 bg-slate-800/60 rounded-lg text-sm text-cyan-400 font-mono">
                JBSW Y3DP EHPK 3PXP
              </code>
              <p className="text-xs text-slate-500">Or enter this setup key manually</p>
              <button
                onClick={() => { setTwoFAEnabled(true); setShow2FAModal(false); }}
                className="w-full py-2.5 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg transition-all"
              >
                I've scanned the code — Enable 2FA
              </button>
            </>
          ) : (
            <>
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8 text-emerald-400" />
              </div>
              <p className="text-white font-semibold">2FA is Enabled</p>
              <p className="text-sm text-slate-400">Your account is protected with two-factor authentication.</p>
              <button
                onClick={() => { setTwoFAEnabled(false); setShow2FAModal(false); }}
                className="w-full py-2.5 bg-red-500/20 text-red-400 border border-red-500/30 text-sm font-semibold rounded-xl hover:bg-red-500/30 transition-colors"
              >
                Disable 2FA
              </button>
            </>
          )}
        </div>
      </Modal>

      {/* Sessions Modal */}
      <Modal open={showSessionsModal} onClose={() => setShowSessionsModal(false)} title="Active Sessions" size="md">
        <div className="space-y-3">
          {[
            { device: 'MacBook Pro — Chrome', location: 'New York, US', time: 'Current session', icon: <Monitor className="w-5 h-5" />, current: true },
            { device: 'iPhone 15 — Safari', location: 'New York, US', time: '2 hours ago', icon: <Smartphone className="w-5 h-5" />, current: false },
            { device: 'Windows PC — Firefox', location: 'San Francisco, US', time: '1 day ago', icon: <Monitor className="w-5 h-5" />, current: false },
          ].map((s, i) => (
            <div key={i} className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="text-slate-400">{s.icon}</div>
                <div>
                  <p className="text-sm text-white font-medium flex items-center gap-2">
                    {s.device}
                    {s.current && <span className="text-[10px] text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded-full">This device</span>}
                  </p>
                  <p className="text-xs text-slate-500">{s.location} · {s.time}</p>
                </div>
              </div>
              {!s.current && (
                <button className="flex items-center gap-1 text-sm text-red-400 hover:text-red-300 font-medium">
                  <LogOut className="w-3.5 h-3.5" /> Revoke
                </button>
              )}
            </div>
          ))}
          <button className="w-full py-2.5 bg-red-500/10 text-red-400 border border-red-500/20 text-sm font-medium rounded-xl hover:bg-red-500/20 transition-colors flex items-center justify-center gap-2">
            <LogOut className="w-4 h-4" /> Revoke All Other Sessions
          </button>
        </div>
      </Modal>

      {/* Login History Modal */}
      <Modal open={showLoginHistory} onClose={() => setShowLoginHistory(false)} title="Login History" size="md">
        <div className="space-y-2">
          {[
            { time: 'Today, 9:42 AM', ip: '192.168.1.42', location: 'New York, US', device: 'Chrome / macOS', status: 'success' },
            { time: 'Today, 8:15 AM', ip: '192.168.1.42', location: 'New York, US', device: 'Safari / iOS', status: 'success' },
            { time: 'Yesterday, 6:30 PM', ip: '10.0.0.15', location: 'San Francisco, US', device: 'Firefox / Windows', status: 'success' },
            { time: 'Yesterday, 2:12 PM', ip: '203.0.113.42', location: 'Unknown', device: 'Unknown', status: 'failed' },
            { time: 'Dec 10, 11:00 AM', ip: '192.168.1.42', location: 'New York, US', device: 'Chrome / macOS', status: 'success' },
            { time: 'Dec 9, 9:30 AM', ip: '192.168.1.42', location: 'New York, US', device: 'Chrome / macOS', status: 'success' },
          ].map((log, i) => (
            <div key={i} className={`flex items-center justify-between p-3 rounded-xl ${log.status === 'failed' ? 'bg-red-500/5 border border-red-500/20' : 'bg-slate-800/30'}`}>
              <div className="flex items-center gap-3">
                {log.status === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-red-400" />}
                <div>
                  <p className="text-sm text-white">{log.time}</p>
                  <p className="text-xs text-slate-500">{log.device} · {log.location} · {log.ip}</p>
                </div>
              </div>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${log.status === 'success' ? 'text-emerald-400 bg-emerald-400/10' : 'text-red-400 bg-red-400/10'}`}>
                {log.status}
              </span>
            </div>
          ))}
        </div>
      </Modal>

      {/* Generate API Key Modal */}
      <Modal open={showKeyModal} onClose={() => { setShowKeyModal(false); setGeneratedKey(null); }} title="Generate New API Key" size="sm">
        <div className="space-y-4">
          {!generatedKey ? (
            <>
              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Key Name</label>
                <input value={newKeyName} onChange={e => setNewKeyName(e.target.value)} placeholder="e.g., Staging Key" className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50" />
              </div>
              <button
                onClick={generateApiKey}
                disabled={!newKeyName.trim()}
                className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                  !newKeyName.trim() ? 'bg-slate-800/50 text-slate-500 cursor-not-allowed' :
                  'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg'
                }`}
              >
                <Key className="w-4 h-4" /> Generate Key
              </button>
            </>
          ) : (
            <>
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm mb-2">
                  <CheckCircle2 className="w-4 h-4" /> Key Generated Successfully
                </div>
                <p className="text-xs text-slate-400 mb-2">Copy this key now — you won't be able to see it again!</p>
                <code className="block px-3 py-2 bg-slate-900/80 rounded-lg text-sm text-cyan-400 font-mono break-all">
                  {generatedKey}
                </code>
              </div>
              <button
                onClick={() => { navigator.clipboard.writeText(generatedKey); }}
                className="w-full py-2.5 bg-violet-500/20 text-violet-300 border border-violet-500/30 text-sm font-semibold rounded-xl hover:bg-violet-500/30 transition-colors flex items-center justify-center gap-2"
              >
                <Copy className="w-4 h-4" /> Copy to Clipboard
              </button>
              <button
                onClick={() => { setShowKeyModal(false); setGeneratedKey(null); }}
                className="w-full py-2.5 bg-slate-800/80 text-slate-300 text-sm font-medium rounded-xl hover:bg-slate-700/80 transition-all border border-slate-700/50"
              >
                Done
              </button>
            </>
          )}
        </div>
      </Modal>

      {/* Upgrade Modal */}
      <Modal open={showUpgrade} onClose={() => setShowUpgrade(false)} title="Upgrade Plan" size="lg">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { name: 'Starter', price: '$49', features: ['5,000 runs/mo', '3 AI agents', '10 integrations', 'Email support'], current: false },
            { name: 'Pro', price: '$149', features: ['50,000 runs/mo', '10 AI agents', 'Unlimited integrations', 'Priority support', 'Custom workflows'], current: true },
            { name: 'Enterprise', price: 'Custom', features: ['Unlimited runs', 'Unlimited agents', 'SSO & SAML', 'Dedicated support', 'SLA guarantee', 'On-premise option'], current: false },
          ].map(plan => (
            <div key={plan.name} className={`p-5 rounded-xl border ${plan.current ? 'border-violet-500/40 bg-violet-500/5' : 'border-slate-700/50 bg-slate-800/30'}`}>
              <h4 className="text-white font-bold">{plan.name}</h4>
              <p className="text-2xl font-bold text-white mt-2">{plan.price}<span className="text-sm text-slate-500 font-normal">/mo</span></p>
              <ul className="mt-4 space-y-2">
                {plan.features.map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> {f}
                  </li>
                ))}
              </ul>
              <button className={`w-full mt-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                plan.current ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg'
              }`}>
                {plan.current ? 'Current Plan' : 'Upgrade'}
              </button>
            </div>
          ))}
        </div>
      </Modal>
    </div>
  );
}

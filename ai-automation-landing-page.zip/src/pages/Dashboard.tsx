import {
  Zap, TrendingUp, Clock, CheckCircle2, AlertTriangle, ArrowUpRight, ArrowDownRight,
  Play, Pause, MoreHorizontal, Bot, Workflow, Activity
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const areaData = [
  { name: 'Mon', automations: 124, saved: 18 },
  { name: 'Tue', automations: 189, saved: 26 },
  { name: 'Wed', automations: 156, saved: 22 },
  { name: 'Thu', automations: 234, saved: 31 },
  { name: 'Fri', automations: 278, saved: 38 },
  { name: 'Sat', automations: 198, saved: 27 },
  { name: 'Sun', automations: 312, saved: 42 },
];

const barData = [
  { name: 'Email', runs: 456 },
  { name: 'CRM', runs: 321 },
  { name: 'Slack', runs: 278 },
  { name: 'Sheets', runs: 189 },
  { name: 'API', runs: 145 },
  { name: 'AI', runs: 398 },
];

const recentRuns = [
  { id: 1, name: 'Lead Qualification Pipeline', status: 'success', time: '2 min ago', duration: '1.2s', agent: 'LeadBot' },
  { id: 2, name: 'Customer Onboarding Flow', status: 'running', time: 'Now', duration: '—', agent: 'OnboardAI' },
  { id: 3, name: 'Invoice Processing', status: 'success', time: '5 min ago', duration: '3.4s', agent: 'FinanceBot' },
  { id: 4, name: 'Social Media Scheduler', status: 'failed', time: '12 min ago', duration: '0.8s', agent: 'SocialAI' },
  { id: 5, name: 'Support Ticket Router', status: 'success', time: '15 min ago', duration: '0.5s', agent: 'SupportBot' },
  { id: 6, name: 'Data Sync — Salesforce', status: 'success', time: '22 min ago', duration: '2.1s', agent: 'SyncAgent' },
];

const stats = [
  { label: 'Total Runs Today', value: '1,847', change: '+12.5%', up: true, icon: Zap, color: 'from-violet-500 to-purple-600' },
  { label: 'Hours Saved', value: '164', change: '+8.2%', up: true, icon: Clock, color: 'from-cyan-500 to-blue-600' },
  { label: 'Success Rate', value: '99.2%', change: '+0.3%', up: true, icon: CheckCircle2, color: 'from-emerald-500 to-green-600' },
  { label: 'Active Workflows', value: '24', change: '+3', up: true, icon: Workflow, color: 'from-amber-500 to-orange-600' },
];

export default function Dashboard({ onNavigate }: { onNavigate: (tab: string) => void }) {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-violet-600/20 via-purple-600/10 to-cyan-600/20 border border-violet-500/20 p-6">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-violet-500/10 to-cyan-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="relative">
          <h1 className="text-2xl font-bold text-white">Good morning, John! 👋</h1>
          <p className="text-slate-400 mt-1">Your AI agents have processed <span className="text-cyan-400 font-semibold">1,847 tasks</span> today and saved you <span className="text-violet-400 font-semibold">164 hours</span> of manual work.</p>
          <div className="flex gap-3 mt-4">
            <button onClick={() => onNavigate('builder')} className="px-4 py-2 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-violet-500/25 transition-all">
              <span className="flex items-center gap-2"><Zap className="w-4 h-4" /> Create Workflow</span>
            </button>
            <button onClick={() => onNavigate('agents')} className="px-4 py-2 bg-slate-800/80 text-white text-sm font-semibold rounded-xl hover:bg-slate-700/80 transition-all border border-slate-700/50">
              <span className="flex items-center gap-2"><Bot className="w-4 h-4" /> Manage Agents</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5 hover:border-slate-700/60 transition-all group">
              <div className="flex items-start justify-between">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full ${stat.up ? 'text-emerald-400 bg-emerald-400/10' : 'text-red-400 bg-red-400/10'}`}>
                  {stat.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {stat.change}
                </div>
              </div>
              <p className="text-2xl font-bold text-white mt-3">{stat.value}</p>
              <p className="text-sm text-slate-500 mt-0.5">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Area chart */}
        <div className="xl:col-span-2 bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-semibold">Automation Runs</h3>
              <p className="text-sm text-slate-500">Last 7 days performance</p>
            </div>
            <div className="flex gap-2">
              <span className="flex items-center gap-1.5 text-xs text-slate-400"><span className="w-2 h-2 rounded-full bg-violet-500" />Runs</span>
              <span className="flex items-center gap-1.5 text-xs text-slate-400"><span className="w-2 h-2 rounded-full bg-cyan-500" />Hours Saved</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={areaData}>
              <defs>
                <linearGradient id="colorAutomations" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorSaved" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" stroke="#475569" fontSize={12} />
              <YAxis stroke="#475569" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 13 }} />
              <Area type="monotone" dataKey="automations" stroke="#8b5cf6" fill="url(#colorAutomations)" strokeWidth={2} />
              <Area type="monotone" dataKey="saved" stroke="#06b6d4" fill="url(#colorSaved)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Bar chart */}
        <div className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-1">Runs by Integration</h3>
          <p className="text-sm text-slate-500 mb-4">Top performing connectors</p>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={barData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
              <XAxis type="number" stroke="#475569" fontSize={12} />
              <YAxis dataKey="name" type="category" stroke="#475569" fontSize={12} width={50} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: 13 }} />
              <Bar dataKey="runs" fill="#8b5cf6" radius={[0, 6, 6, 0]} barSize={20} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent runs */}
      <div className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-white font-semibold">Recent Automation Runs</h3>
            <p className="text-sm text-slate-500">Real-time execution log</p>
          </div>
          <button className="text-sm text-violet-400 hover:text-violet-300 font-medium flex items-center gap-1">
            View All <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-xs text-slate-500 uppercase tracking-wider border-b border-slate-800/60">
                <th className="text-left py-3 px-3">Workflow</th>
                <th className="text-left py-3 px-3">Agent</th>
                <th className="text-left py-3 px-3">Status</th>
                <th className="text-left py-3 px-3">Duration</th>
                <th className="text-left py-3 px-3">Time</th>
                <th className="text-right py-3 px-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {recentRuns.map((run) => (
                <tr key={run.id} className="border-b border-slate-800/30 hover:bg-slate-800/20 transition-colors">
                  <td className="py-3 px-3">
                    <span className="text-sm text-white font-medium">{run.name}</span>
                  </td>
                  <td className="py-3 px-3">
                    <span className="text-sm text-slate-400 flex items-center gap-1.5">
                      <Bot className="w-3.5 h-3.5 text-violet-400" />
                      {run.agent}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${
                      run.status === 'success' ? 'text-emerald-400 bg-emerald-400/10' :
                      run.status === 'running' ? 'text-cyan-400 bg-cyan-400/10' :
                      'text-red-400 bg-red-400/10'
                    }`}>
                      {run.status === 'success' && <CheckCircle2 className="w-3 h-3" />}
                      {run.status === 'running' && <Activity className="w-3 h-3 animate-pulse" />}
                      {run.status === 'failed' && <AlertTriangle className="w-3 h-3" />}
                      {run.status.charAt(0).toUpperCase() + run.status.slice(1)}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-sm text-slate-400">{run.duration}</td>
                  <td className="py-3 px-3 text-sm text-slate-500">{run.time}</td>
                  <td className="py-3 px-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {run.status === 'running' ? (
                        <button className="p-1.5 rounded-lg hover:bg-slate-700/50 text-slate-400 hover:text-white transition-colors"><Pause className="w-3.5 h-3.5" /></button>
                      ) : (
                        <button className="p-1.5 rounded-lg hover:bg-slate-700/50 text-slate-400 hover:text-white transition-colors"><Play className="w-3.5 h-3.5" /></button>
                      )}
                      <button className="p-1.5 rounded-lg hover:bg-slate-700/50 text-slate-400 hover:text-white transition-colors"><MoreHorizontal className="w-3.5 h-3.5" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button onClick={() => onNavigate('builder')} className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5 hover:border-violet-500/30 transition-all group text-left">
          <div className="w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center mb-3 group-hover:bg-violet-500/20 transition-colors">
            <Zap className="w-5 h-5 text-violet-400" />
          </div>
          <h4 className="text-white font-semibold text-sm">Build New Workflow</h4>
          <p className="text-xs text-slate-500 mt-1">Create from scratch or use a template</p>
        </button>
        <button onClick={() => onNavigate('agents')} className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5 hover:border-cyan-500/30 transition-all group text-left">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-3 group-hover:bg-cyan-500/20 transition-colors">
            <Bot className="w-5 h-5 text-cyan-400" />
          </div>
          <h4 className="text-white font-semibold text-sm">Deploy AI Agent</h4>
          <p className="text-xs text-slate-500 mt-1">Spin up a new intelligent agent</p>
        </button>
        <button onClick={() => onNavigate('integrations')} className="bg-slate-900/80 border border-slate-800/60 rounded-2xl p-5 hover:border-emerald-500/30 transition-all group text-left">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-3 group-hover:bg-emerald-500/20 transition-colors">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
          </div>
          <h4 className="text-white font-semibold text-sm">Add Integration</h4>
          <p className="text-xs text-slate-500 mt-1">Connect 500+ apps and services</p>
        </button>
      </div>
    </div>
  );
}

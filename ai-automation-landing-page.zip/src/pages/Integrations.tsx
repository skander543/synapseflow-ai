import { useState } from 'react';
import { Search, Check, ExternalLink, Zap, Star, Settings, CheckCircle2, AlertTriangle, Clock, Activity } from 'lucide-react';
import Modal from '../components/Modal';

interface Integration {
  id: string;
  name: string;
  category: string;
  description: string;
  connected: boolean;
  popular: boolean;
  icon: string;
  color: string;
  docs: string;
  features: string[];
}

const integrationsData: Integration[] = [
  { id: '1', name: 'Slack', category: 'Communication', description: 'Send messages and notifications to channels', connected: true, popular: true, icon: '💬', color: 'bg-purple-500/10 border-purple-500/20', docs: 'https://api.slack.com', features: ['Send messages to channels', 'Create threads', 'Upload files', 'Manage reactions', 'User lookups'] },
  { id: '2', name: 'Gmail', category: 'Email', description: 'Read, send, and manage emails', connected: true, popular: true, icon: '📧', color: 'bg-red-500/10 border-red-500/20', docs: 'https://developers.google.com/gmail', features: ['Read inbox', 'Send emails', 'Create drafts', 'Manage labels', 'Search emails'] },
  { id: '3', name: 'Salesforce', category: 'CRM', description: 'Sync leads, contacts, and deals', connected: true, popular: true, icon: '☁️', color: 'bg-blue-500/10 border-blue-500/20', docs: 'https://developer.salesforce.com', features: ['Sync contacts', 'Manage leads', 'Track opportunities', 'Custom objects', 'Reports API'] },
  { id: '4', name: 'Google Sheets', category: 'Productivity', description: 'Read and write spreadsheet data', connected: true, popular: true, icon: '📊', color: 'bg-green-500/10 border-green-500/20', docs: 'https://developers.google.com/sheets', features: ['Read cells', 'Write data', 'Create sheets', 'Format cells', 'Batch updates'] },
  { id: '5', name: 'HubSpot', category: 'CRM', description: 'Marketing, sales, and service automation', connected: false, popular: true, icon: '🟠', color: 'bg-orange-500/10 border-orange-500/20', docs: 'https://developers.hubspot.com', features: ['Contact management', 'Deal tracking', 'Email marketing', 'Forms', 'Tickets'] },
  { id: '6', name: 'Stripe', category: 'Payments', description: 'Process payments and manage billing', connected: true, popular: true, icon: '💳', color: 'bg-indigo-500/10 border-indigo-500/20', docs: 'https://stripe.com/docs', features: ['Process payments', 'Manage subscriptions', 'Invoice generation', 'Refunds', 'Customer portal'] },
  { id: '7', name: 'Notion', category: 'Productivity', description: 'Create and manage documentation', connected: false, popular: false, icon: '📝', color: 'bg-slate-500/10 border-slate-500/20', docs: 'https://developers.notion.com', features: ['Create pages', 'Update databases', 'Search content', 'Manage blocks', 'Comments'] },
  { id: '8', name: 'Zapier', category: 'Automation', description: 'Connect with 5000+ apps via Zapier', connected: false, popular: true, icon: '⚡', color: 'bg-amber-500/10 border-amber-500/20', docs: 'https://platform.zapier.com', features: ['Trigger Zaps', 'Multi-step workflows', '5000+ app connections', 'Webhooks', 'Filters'] },
  { id: '9', name: 'Twilio', category: 'Communication', description: 'Send SMS and make voice calls', connected: false, popular: false, icon: '📞', color: 'bg-red-500/10 border-red-500/20', docs: 'https://www.twilio.com/docs', features: ['Send SMS', 'Voice calls', 'WhatsApp', 'Video', 'Phone number management'] },
  { id: '10', name: 'Shopify', category: 'E-Commerce', description: 'Manage orders, products, and customers', connected: false, popular: true, icon: '🛒', color: 'bg-green-500/10 border-green-500/20', docs: 'https://shopify.dev', features: ['Order management', 'Product sync', 'Customer data', 'Inventory tracking', 'Fulfillment'] },
  { id: '11', name: 'Jira', category: 'Project Management', description: 'Create and track issues and sprints', connected: true, popular: false, icon: '🔷', color: 'bg-blue-500/10 border-blue-500/20', docs: 'https://developer.atlassian.com', features: ['Create issues', 'Update status', 'Sprint management', 'Comments', 'Attachments'] },
  { id: '12', name: 'Airtable', category: 'Database', description: 'Read and update base records', connected: false, popular: false, icon: '📋', color: 'bg-yellow-500/10 border-yellow-500/20', docs: 'https://airtable.com/developers', features: ['Read records', 'Create entries', 'Update fields', 'Attachments', 'Linked records'] },
  { id: '13', name: 'Microsoft Teams', category: 'Communication', description: 'Post messages and manage channels', connected: false, popular: true, icon: '🟣', color: 'bg-violet-500/10 border-violet-500/20', docs: 'https://learn.microsoft.com/graph', features: ['Post messages', 'Create channels', 'Schedule meetings', 'File sharing', 'Adaptive cards'] },
  { id: '14', name: 'PostgreSQL', category: 'Database', description: 'Query and write to your database', connected: true, popular: false, icon: '🐘', color: 'bg-blue-500/10 border-blue-500/20', docs: 'https://www.postgresql.org/docs', features: ['SQL queries', 'Inserts/Updates', 'Transactions', 'Stored procedures', 'Connection pooling'] },
  { id: '15', name: 'OpenAI', category: 'AI', description: 'GPT-4, DALL-E, and Whisper APIs', connected: true, popular: true, icon: '🤖', color: 'bg-emerald-500/10 border-emerald-500/20', docs: 'https://platform.openai.com', features: ['Chat completions', 'Embeddings', 'Image generation', 'Audio transcription', 'Fine-tuning'] },
  { id: '16', name: 'AWS S3', category: 'Storage', description: 'Upload, download, and manage files', connected: false, popular: false, icon: '☁️', color: 'bg-orange-500/10 border-orange-500/20', docs: 'https://docs.aws.amazon.com/s3', features: ['Upload files', 'Download objects', 'Bucket management', 'Pre-signed URLs', 'Lifecycle rules'] },
  { id: '17', name: 'Intercom', category: 'Support', description: 'Manage conversations and contacts', connected: false, popular: false, icon: '🗨️', color: 'bg-blue-500/10 border-blue-500/20', docs: 'https://developers.intercom.com', features: ['Manage conversations', 'Contact management', 'Send messages', 'Custom attributes', 'Tags'] },
  { id: '18', name: 'Mailchimp', category: 'Marketing', description: 'Manage email campaigns and lists', connected: false, popular: false, icon: '🐵', color: 'bg-yellow-500/10 border-yellow-500/20', docs: 'https://mailchimp.com/developer', features: ['Manage lists', 'Create campaigns', 'Send emails', 'Audience segmentation', 'Analytics'] },
];

const categories = ['All', 'Communication', 'CRM', 'Email', 'Productivity', 'Payments', 'AI', 'Database', 'E-Commerce', 'Marketing'];

export default function Integrations() {
  const [integrations, setIntegrations] = useState(integrationsData);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [showConnected, setShowConnected] = useState(false);
  const [detailIntegration, setDetailIntegration] = useState<Integration | null>(null);
  const [connecting, setConnecting] = useState<string | null>(null);

  const filtered = integrations.filter(i => {
    const matchesSearch = i.name.toLowerCase().includes(search.toLowerCase()) || i.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === 'All' || i.category === category;
    const matchesConnected = !showConnected || i.connected;
    return matchesSearch && matchesCategory && matchesConnected;
  });

  const connectedCount = integrations.filter(i => i.connected).length;

  const toggleConnection = (id: string) => {
    const integration = integrations.find(i => i.id === id);
    if (integration && !integration.connected) {
      setConnecting(id);
      setTimeout(() => {
        setIntegrations(prev => prev.map(i =>
          i.id === id ? { ...i, connected: true } : i
        ));
        setConnecting(null);
        if (detailIntegration?.id === id) {
          setDetailIntegration(prev => prev ? { ...prev, connected: true } : null);
        }
      }, 1500);
    } else {
      setIntegrations(prev => prev.map(i =>
        i.id === id ? { ...i, connected: false } : i
      ));
      if (detailIntegration?.id === id) {
        setDetailIntegration(prev => prev ? { ...prev, connected: false } : null);
      }
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Zap className="w-7 h-7 text-violet-400" />
            Integrations
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            {connectedCount} connected · {integrations.length} available
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowConnected(!showConnected)}
            className={`px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
              showConnected ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : 'bg-slate-900/80 text-slate-400 border border-slate-800/60 hover:text-white'
            }`}
          >
            Connected Only
          </button>
        </div>
      </div>

      {/* Search and categories */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search integrations..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900/80 border border-slate-800/60 rounded-xl text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-violet-500/50"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                category === cat ? 'bg-violet-500/20 text-violet-300' : 'text-slate-500 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Integration grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((integration) => (
          <div
            key={integration.id}
            className={`bg-slate-900/80 border rounded-2xl p-5 transition-all hover:shadow-lg cursor-pointer group ${
              integration.connected ? 'border-emerald-500/20 hover:border-emerald-500/30' : 'border-slate-800/60 hover:border-slate-700/60'
            }`}
            onClick={() => setDetailIntegration(integration)}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl ${integration.color} border flex items-center justify-center text-2xl`}>
                  {integration.icon}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-white font-semibold">{integration.name}</h3>
                    {integration.popular && <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />}
                  </div>
                  <p className="text-xs text-slate-500">{integration.category}</p>
                </div>
              </div>
              {integration.connected && (
                <div className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full">
                  <Check className="w-3 h-3" /> Connected
                </div>
              )}
            </div>

            <p className="text-sm text-slate-400 mt-3">{integration.description}</p>

            <div className="flex gap-2 mt-4">
              <button
                onClick={(e) => { e.stopPropagation(); toggleConnection(integration.id); }}
                className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                  connecting === integration.id
                    ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30'
                    : integration.connected
                    ? 'bg-slate-800/50 text-slate-300 border border-slate-700/50 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30'
                    : 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg hover:shadow-violet-500/25'
                }`}
              >
                {connecting === integration.id ? (
                  <><div className="w-3.5 h-3.5 border-2 border-violet-300 border-t-transparent rounded-full animate-spin" /> Connecting...</>
                ) : (
                  integration.connected ? 'Disconnect' : 'Connect'
                )}
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); setDetailIntegration(integration); }}
                className="px-3 py-2 rounded-xl text-sm text-slate-400 bg-slate-800/50 border border-slate-700/50 hover:text-white transition-colors"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <Search className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-white font-semibold">No integrations found</h3>
          <p className="text-sm text-slate-500 mt-1">Try adjusting your search or category filter</p>
        </div>
      )}

      {/* Integration Detail Modal */}
      <Modal open={!!detailIntegration} onClose={() => setDetailIntegration(null)} title={detailIntegration?.name || ''} size="lg">
        {detailIntegration && (
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center gap-4">
              <div className={`w-16 h-16 rounded-2xl ${detailIntegration.color} border flex items-center justify-center text-3xl`}>
                {detailIntegration.icon}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-bold text-white">{detailIntegration.name}</h3>
                  {detailIntegration.popular && <Star className="w-4 h-4 text-amber-400 fill-amber-400" />}
                  {detailIntegration.connected ? (
                    <span className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full"><Check className="w-3 h-3" /> Connected</span>
                  ) : (
                    <span className="text-xs text-slate-400 bg-slate-800/50 px-2 py-1 rounded-full">Not Connected</span>
                  )}
                </div>
                <p className="text-sm text-slate-400 mt-1">{detailIntegration.description}</p>
                <p className="text-xs text-slate-500 mt-1">Category: {detailIntegration.category}</p>
              </div>
            </div>

            {/* Connection Status */}
            {detailIntegration.connected && (
              <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
                <h4 className="text-sm font-semibold text-emerald-400 flex items-center gap-2 mb-3">
                  <Activity className="w-4 h-4" /> Connection Health
                </h4>
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center">
                    <p className="text-xs text-slate-500">Status</p>
                    <p className="text-sm font-bold text-emerald-400 flex items-center justify-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Active</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-slate-500">Last Sync</p>
                    <p className="text-sm font-bold text-white flex items-center justify-center gap-1"><Clock className="w-3 h-3 text-slate-400" /> 2 min ago</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-slate-500">API Calls Today</p>
                    <p className="text-sm font-bold text-white">{Math.floor(Math.random() * 500 + 100)}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Features */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-3">Capabilities</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {detailIntegration.features.map(f => (
                  <div key={f} className="flex items-center gap-2 text-sm text-slate-300 p-2 bg-slate-800/30 rounded-lg">
                    <CheckCircle2 className="w-3.5 h-3.5 text-violet-400 flex-shrink-0" /> {f}
                  </div>
                ))}
              </div>
            </div>

            {/* Config */}
            {detailIntegration.connected && (
              <div>
                <h4 className="text-sm font-semibold text-white mb-3">Configuration</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Sync Frequency</label>
                    <select className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                      <option>Real-time</option>
                      <option>Every 5 minutes</option>
                      <option>Every 15 minutes</option>
                      <option>Every hour</option>
                      <option>Daily</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Error Handling</label>
                    <select className="w-full mt-1.5 px-3 py-2.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                      <option>Retry 3 times then alert</option>
                      <option>Retry 5 times then skip</option>
                      <option>Fail immediately</option>
                      <option>Log and continue</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-3 pt-3 border-t border-slate-800/60">
              <button
                onClick={() => toggleConnection(detailIntegration.id)}
                className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                  connecting === detailIntegration.id
                    ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30'
                    : detailIntegration.connected
                    ? 'bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20'
                    : 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg hover:shadow-violet-500/25'
                }`}
              >
                {connecting === detailIntegration.id ? (
                  <><div className="w-4 h-4 border-2 border-violet-300 border-t-transparent rounded-full animate-spin" /> Connecting...</>
                ) : detailIntegration.connected ? (
                  <><AlertTriangle className="w-4 h-4" /> Disconnect</>
                ) : (
                  <><Zap className="w-4 h-4" /> Connect {detailIntegration.name}</>
                )}
              </button>
              <a
                href={detailIntegration.docs}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2.5 rounded-xl text-sm text-slate-400 bg-slate-800/50 border border-slate-700/50 hover:text-white transition-colors flex items-center gap-2"
                onClick={(e) => e.stopPropagation()}
              >
                <ExternalLink className="w-4 h-4" /> Docs
              </a>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

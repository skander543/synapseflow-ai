import { useState, useCallback } from 'react';
import {
  Plus, Play, Save, Trash2, Settings, Mail, Globe, Clock, MessageSquare,
  Database, FileText, Bot, Zap, ArrowRight, GripVertical, X, CheckCircle2,
  Filter, GitBranch, Repeat, Sparkles, AlertTriangle, Webhook, Copy, Download
} from 'lucide-react';

interface WorkflowNode {
  id: string;
  type: 'trigger' | 'action' | 'condition' | 'ai';
  category: string;
  label: string;
  icon: string;
  config: Record<string, string>;
  x: number;
  y: number;
}

const nodeTemplates = {
  triggers: [
    { category: 'Email Received', icon: 'mail', description: 'When a new email arrives' },
    { category: 'Webhook', icon: 'webhook', description: 'On incoming webhook' },
    { category: 'Schedule', icon: 'clock', description: 'Run on a schedule' },
    { category: 'Form Submit', icon: 'filetext', description: 'When form is submitted' },
  ],
  actions: [
    { category: 'Send Email', icon: 'mail', description: 'Send automated email' },
    { category: 'HTTP Request', icon: 'globe', description: 'Make API call' },
    { category: 'Update Database', icon: 'database', description: 'Write to database' },
    { category: 'Send Message', icon: 'message', description: 'Post to Slack/Teams' },
  ],
  ai: [
    { category: 'AI Classify', icon: 'sparkles', description: 'Classify with AI' },
    { category: 'AI Generate', icon: 'bot', description: 'Generate AI response' },
    { category: 'AI Extract', icon: 'filter', description: 'Extract data with AI' },
    { category: 'AI Decide', icon: 'gitbranch', description: 'AI decision routing' },
  ],
  logic: [
    { category: 'If/Else', icon: 'gitbranch', description: 'Conditional branching' },
    { category: 'Loop', icon: 'repeat', description: 'Iterate over items' },
    { category: 'Filter', icon: 'filter', description: 'Filter data' },
    { category: 'Delay', icon: 'clock', description: 'Wait before continuing' },
  ],
};

const iconMap: Record<string, React.ReactNode> = {
  mail: <Mail className="w-4 h-4" />,
  webhook: <Webhook className="w-4 h-4" />,
  clock: <Clock className="w-4 h-4" />,
  filetext: <FileText className="w-4 h-4" />,
  globe: <Globe className="w-4 h-4" />,
  database: <Database className="w-4 h-4" />,
  message: <MessageSquare className="w-4 h-4" />,
  bot: <Bot className="w-4 h-4" />,
  sparkles: <Sparkles className="w-4 h-4" />,
  filter: <Filter className="w-4 h-4" />,
  gitbranch: <GitBranch className="w-4 h-4" />,
  repeat: <Repeat className="w-4 h-4" />,
  zap: <Zap className="w-4 h-4" />,
};

const typeColors: Record<string, { bg: string; border: string; icon: string; glow: string }> = {
  trigger: { bg: 'bg-amber-500/10', border: 'border-amber-500/30', icon: 'text-amber-400', glow: 'shadow-amber-500/10' },
  action: { bg: 'bg-blue-500/10', border: 'border-blue-500/30', icon: 'text-blue-400', glow: 'shadow-blue-500/10' },
  ai: { bg: 'bg-violet-500/10', border: 'border-violet-500/30', icon: 'text-violet-400', glow: 'shadow-violet-500/10' },
  condition: { bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', icon: 'text-emerald-400', glow: 'shadow-emerald-500/10' },
};

export default function WorkflowBuilder() {
  const [nodes, setNodes] = useState<WorkflowNode[]>([
    { id: '1', type: 'trigger', category: 'Email Received', label: 'New Lead Email', icon: 'mail', config: { from: 'leads@*' }, x: 0, y: 0 },
    { id: '2', type: 'ai', category: 'AI Classify', label: 'Qualify Lead', icon: 'sparkles', config: { model: 'GPT-4o' }, x: 0, y: 0 },
    { id: '3', type: 'condition', category: 'If/Else', label: 'Is Qualified?', icon: 'gitbranch', config: { condition: 'score > 70' }, x: 0, y: 0 },
    { id: '4', type: 'action', category: 'Update Database', label: 'Add to CRM', icon: 'database', config: { table: 'leads' }, x: 0, y: 0 },
    { id: '5', type: 'action', category: 'Send Email', label: 'Send Welcome', icon: 'mail', config: { template: 'welcome_qualified' }, x: 0, y: 0 },
  ]);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [showPanel, setShowPanel] = useState(true);
  const [panelTab, setPanelTab] = useState<'triggers' | 'actions' | 'ai' | 'logic'>('triggers');
  const [workflowName, setWorkflowName] = useState('Lead Qualification Pipeline');
  const [saved, setSaved] = useState(false);
  const [running, setRunning] = useState(false);
  const [runningNodeIndex, setRunningNodeIndex] = useState(-1);
  const [nodeStatuses, setNodeStatuses] = useState<Record<string, 'idle' | 'running' | 'success' | 'error'>>({});
  const [runComplete, setRunComplete] = useState(false);
  const [runLogs, setRunLogs] = useState<string[]>([]);
  const [duplicated, setDuplicated] = useState(false);

  const addNode = useCallback((type: 'trigger' | 'action' | 'ai' | 'condition', category: string, icon: string) => {
    const newNode: WorkflowNode = {
      id: Date.now().toString(),
      type,
      category,
      label: category,
      icon,
      config: {},
      x: 0,
      y: 0,
    };
    setNodes(prev => [...prev, newNode]);
  }, []);

  const removeNode = useCallback((id: string) => {
    setNodes(prev => prev.filter(n => n.id !== id));
    if (selectedNode === id) setSelectedNode(null);
  }, [selectedNode]);

  const moveNode = useCallback((id: string, direction: 'up' | 'down') => {
    setNodes(prev => {
      const idx = prev.findIndex(n => n.id === id);
      if ((direction === 'up' && idx <= 0) || (direction === 'down' && idx >= prev.length - 1)) return prev;
      const newNodes = [...prev];
      const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
      [newNodes[idx], newNodes[swapIdx]] = [newNodes[swapIdx], newNodes[idx]];
      return newNodes;
    });
  }, []);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleDuplicate = () => {
    setDuplicated(true);
    setTimeout(() => setDuplicated(false), 2000);
  };

  const handleExport = () => {
    const data = JSON.stringify({ name: workflowName, nodes }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${workflowName.replace(/\s+/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRun = () => {
    if (nodes.length === 0) return;
    setRunning(true);
    setRunComplete(false);
    setRunLogs([]);
    setNodeStatuses({});

    const logMessages = [
      '🔄 Initializing workflow run...',
      '📧 Trigger: Checking for new lead emails...',
      '📧 Found 1 new lead email from alex@startup.io',
      '🤖 AI: Analyzing lead with GPT-4o...',
      '🤖 Lead scored: 87/100 — High buying intent detected',
      '🔀 Condition: score 87 > 70 → Qualified ✓',
      '💾 Action: Creating CRM record...',
      '💾 Lead added to CRM: ID #4522, Pipeline: Enterprise',
      '📧 Action: Sending welcome email...',
      '📧 Welcome email sent to alex@startup.io',
      '✅ Workflow completed successfully in 1.8s',
    ];

    // Step through nodes one by one
    nodes.forEach((node, i) => {
      setTimeout(() => {
        setRunningNodeIndex(i);
        setNodeStatuses(prev => ({ ...prev, [node.id]: 'running' }));

        // Add relevant logs
        const logsToAdd = logMessages.slice(i * 2 + 1, i * 2 + 3).filter(Boolean);
        logsToAdd.forEach((log, j) => {
          setTimeout(() => {
            setRunLogs(prev => [...prev, log]);
          }, j * 300);
        });

        setTimeout(() => {
          setNodeStatuses(prev => ({ ...prev, [node.id]: 'success' }));
        }, 600);
      }, i * 800);
    });

    // Wrap up
    setTimeout(() => {
      setRunLogs(prev => [...prev, logMessages[logMessages.length - 1]]);
      setRunning(false);
      setRunningNodeIndex(-1);
      setRunComplete(true);
      setTimeout(() => setRunComplete(false), 5000);
    }, nodes.length * 800 + 400);
  };

  const selectedNodeData = nodes.find(n => n.id === selectedNode);

  return (
    <div className="animate-fade-in h-[calc(100vh-5rem)] flex flex-col">
      {/* Top bar */}
      <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800/60 rounded-2xl p-3 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <input
            value={workflowName}
            onChange={(e) => setWorkflowName(e.target.value)}
            className="bg-transparent text-white font-semibold text-lg border-none outline-none focus:ring-0 w-72"
          />
          <span className="text-xs text-slate-500 bg-slate-800/60 px-2 py-1 rounded-full">{nodes.length} nodes</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700/80 border border-slate-700/50 transition-all"
          >
            <Download className="w-4 h-4" /> Export
          </button>
          <button
            onClick={handleDuplicate}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
              duplicated ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700/80 border border-slate-700/50'
            }`}
          >
            <Copy className="w-4 h-4" /> {duplicated ? 'Duplicated!' : 'Duplicate'}
          </button>
          <button
            onClick={handleSave}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              saved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800/80 text-white hover:bg-slate-700/80 border border-slate-700/50'
            }`}
          >
            {saved ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            {saved ? 'Saved!' : 'Save'}
          </button>
          <button
            onClick={handleRun}
            disabled={running || nodes.length === 0}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
              running
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                : runComplete
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg hover:shadow-violet-500/25'
            }`}
          >
            {runComplete ? <><CheckCircle2 className="w-4 h-4" /> Passed!</> :
             <><Play className={`w-4 h-4 ${running ? 'animate-pulse' : ''}`} />{running ? 'Running...' : 'Test Run'}</>}
          </button>
        </div>
      </div>

      {/* Main builder area */}
      <div className="flex-1 flex gap-4 min-h-0">
        {/* Node palette */}
        {showPanel && (
          <div className="w-72 bg-slate-900/80 border border-slate-800/60 rounded-2xl p-4 flex flex-col overflow-hidden flex-shrink-0">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-semibold text-sm">Add Node</h3>
              <button onClick={() => setShowPanel(false)} className="text-slate-500 hover:text-white transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex gap-1 mb-3">
              {(['triggers', 'actions', 'ai', 'logic'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setPanelTab(tab)}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors capitalize ${
                    panelTab === tab ? 'bg-violet-500/20 text-violet-300' : 'text-slate-500 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
            <div className="space-y-2 overflow-y-auto flex-1 pr-1">
              {nodeTemplates[panelTab].map((tmpl) => (
                <button
                  key={tmpl.category}
                  onClick={() => addNode(
                    panelTab === 'triggers' ? 'trigger' : panelTab === 'logic' ? 'condition' : panelTab as 'action' | 'ai',
                    tmpl.category,
                    tmpl.icon
                  )}
                  className="w-full flex items-center gap-3 p-3 rounded-xl bg-slate-800/30 border border-slate-700/30 hover:border-violet-500/30 hover:bg-slate-800/60 transition-all text-left group"
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    panelTab === 'triggers' ? 'bg-amber-500/10 text-amber-400' :
                    panelTab === 'ai' ? 'bg-violet-500/10 text-violet-400' :
                    panelTab === 'logic' ? 'bg-emerald-500/10 text-emerald-400' :
                    'bg-blue-500/10 text-blue-400'
                  }`}>
                    {iconMap[tmpl.icon]}
                  </div>
                  <div>
                    <p className="text-sm text-white font-medium">{tmpl.category}</p>
                    <p className="text-xs text-slate-500">{tmpl.description}</p>
                  </div>
                  <Plus className="w-4 h-4 text-slate-600 group-hover:text-violet-400 ml-auto transition-colors" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Canvas */}
        <div className="flex-1 bg-slate-900/40 border border-slate-800/60 rounded-2xl p-6 overflow-auto relative">
          {!showPanel && (
            <button
              onClick={() => setShowPanel(true)}
              className="absolute top-4 left-4 z-10 w-8 h-8 rounded-lg bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          )}

          {/* Background grid */}
          <div className="absolute inset-0 opacity-[0.03]" style={{
            backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)',
            backgroundSize: '24px 24px',
          }} />

          {/* Flow visualization */}
          <div className="relative flex flex-col items-center gap-2 pt-4">
            {nodes.map((node, index) => {
              const colors = typeColors[node.type];
              const isSelected = selectedNode === node.id;
              const nodeStatus = nodeStatuses[node.id] || 'idle';
              const isRunningNode = running && runningNodeIndex === index;
              const isComplete = nodeStatus === 'success';
              return (
                <div key={node.id}>
                  {/* Connector arrow */}
                  {index > 0 && (
                    <div className="flex flex-col items-center my-1">
                      <div className={`w-0.5 h-6 transition-colors duration-300 ${isComplete || isRunningNode ? 'bg-gradient-to-b from-cyan-400 to-violet-400' : 'bg-slate-700'}`} />
                      <ArrowRight className={`w-3.5 h-3.5 rotate-90 transition-colors duration-300 ${isComplete || isRunningNode ? 'text-cyan-400' : 'text-slate-600'}`} />
                      <div className={`w-0.5 h-3 transition-colors duration-300 ${isComplete || isRunningNode ? 'bg-gradient-to-b from-violet-400 to-cyan-400' : 'bg-slate-700'}`} />
                    </div>
                  )}

                  {/* Node card */}
                  <button
                    onClick={() => setSelectedNode(isSelected ? null : node.id)}
                    className={`relative w-80 flex items-center gap-3 p-4 rounded-2xl border-2 transition-all duration-300 ${colors.bg} ${
                      isRunningNode ? 'border-cyan-400/50 shadow-xl shadow-cyan-500/20 scale-[1.02]' :
                      isComplete ? 'border-emerald-500/40 shadow-lg shadow-emerald-500/10' :
                      isSelected ? `${colors.border} shadow-xl ${colors.glow}` : 'border-slate-700/30 hover:border-slate-600/50'
                    }`}
                  >
                    <GripVertical className="w-4 h-4 text-slate-600 cursor-grab" />
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                      isRunningNode ? 'bg-cyan-500/20 text-cyan-400' :
                      isComplete ? 'bg-emerald-500/20 text-emerald-400' :
                      `${colors.bg} ${colors.icon}`
                    }`}>
                      {isComplete ? <CheckCircle2 className="w-5 h-5" /> :
                       isRunningNode ? <div className="w-5 h-5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" /> :
                       iconMap[node.icon]}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-sm text-white font-semibold">{node.label}</p>
                      <p className="text-xs text-slate-500">{node.category}</p>
                    </div>
                    {isRunningNode && (
                      <span className="text-[10px] text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full animate-pulse">Processing...</span>
                    )}
                    {isComplete && (
                      <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">Done ✓</span>
                    )}
                    {/* Move/Delete controls on hover */}
                    <div className="absolute -right-10 top-1/2 -translate-y-1/2 flex flex-col gap-1 opacity-0 hover:opacity-100 transition-opacity">
                      {index > 0 && (
                        <button onClick={(e) => { e.stopPropagation(); moveNode(node.id, 'up'); }} className="w-6 h-6 rounded bg-slate-800 border border-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white text-xs">↑</button>
                      )}
                      {index < nodes.length - 1 && (
                        <button onClick={(e) => { e.stopPropagation(); moveNode(node.id, 'down'); }} className="w-6 h-6 rounded bg-slate-800 border border-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white text-xs">↓</button>
                      )}
                      <button onClick={(e) => { e.stopPropagation(); removeNode(node.id); }} className="w-6 h-6 rounded bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400 hover:text-red-300 text-xs">×</button>
                    </div>
                  </button>
                </div>
              );
            })}

            {/* Add node button at bottom */}
            <div className="flex flex-col items-center my-1">
              <div className="w-0.5 h-6 bg-slate-700/50" />
              <button
                onClick={() => setShowPanel(true)}
                className="w-10 h-10 rounded-xl border-2 border-dashed border-slate-700/50 flex items-center justify-center text-slate-600 hover:text-violet-400 hover:border-violet-500/30 transition-all"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            {/* Run status & logs */}
            {(running || runLogs.length > 0) && (
              <div className="mt-4 w-96 bg-slate-900/80 border border-slate-800/60 rounded-xl p-4 text-left">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                    {running ? (
                      <><div className="w-3 h-3 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" /> Execution Log</>
                    ) : runComplete ? (
                      <><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Run Complete</>
                    ) : (
                      <><AlertTriangle className="w-4 h-4 text-amber-400" /> Run Log</>
                    )}
                  </h4>
                  {!running && (
                    <button onClick={() => { setRunLogs([]); setRunComplete(false); setNodeStatuses({}); }} className="text-xs text-slate-500 hover:text-white">Clear</button>
                  )}
                </div>
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {runLogs.map((log, i) => (
                    <p key={i} className={`text-xs font-mono animate-slide-up ${
                      log.startsWith('✅') ? 'text-emerald-400' :
                      log.startsWith('🤖') ? 'text-violet-400' :
                      log.startsWith('🔀') ? 'text-emerald-400' :
                      log.startsWith('📧') ? 'text-amber-400' :
                      log.startsWith('💾') ? 'text-blue-400' :
                      'text-slate-400'
                    }`}>{log}</p>
                  ))}
                </div>
                {runComplete && (
                  <div className="mt-3 pt-3 border-t border-slate-800/60 flex items-center justify-between">
                    <span className="text-xs text-emerald-400 font-medium">All {nodes.length} nodes passed</span>
                    <span className="text-xs text-slate-500">Duration: 1.8s</span>
                  </div>
                )}
              </div>
            )}

            {nodes.length === 0 && (
              <div className="text-center py-16">
                <Zap className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <h3 className="text-white font-semibold">Start Building</h3>
                <p className="text-sm text-slate-500 mt-1">Add nodes from the panel to create your workflow</p>
              </div>
            )}
          </div>
        </div>

        {/* Config panel */}
        {selectedNodeData && (
          <div className="w-80 bg-slate-900/80 border border-slate-800/60 rounded-2xl p-4 flex flex-col overflow-auto flex-shrink-0">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold text-sm flex items-center gap-2">
                <Settings className="w-4 h-4 text-violet-400" />
                Configure Node
              </h3>
              <button onClick={() => setSelectedNode(null)} className="text-slate-500 hover:text-white transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Label</label>
                <input
                  value={selectedNodeData.label}
                  onChange={(e) => setNodes(prev => prev.map(n => n.id === selectedNode ? { ...n, label: e.target.value } : n))}
                  className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50"
                />
              </div>

              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Type</label>
                <div className={`mt-1.5 px-3 py-2 rounded-xl text-sm font-medium capitalize ${typeColors[selectedNodeData.type].bg} ${typeColors[selectedNodeData.type].icon}`}>
                  {selectedNodeData.type}
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Category</label>
                <p className="mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm">{selectedNodeData.category}</p>
              </div>

              {selectedNodeData.type === 'ai' && (
                <>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">AI Model</label>
                    <select
                      value={selectedNodeData.config.model || 'GPT-4o'}
                      onChange={(e) => setNodes(prev => prev.map(n => n.id === selectedNode ? { ...n, config: { ...n.config, model: e.target.value } } : n))}
                      className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50"
                    >
                      <option>GPT-4o</option>
                      <option>GPT-4o Mini</option>
                      <option>Claude 3.5 Sonnet</option>
                      <option>Llama 3.1 70B</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Prompt</label>
                    <textarea
                      rows={3}
                      placeholder="Enter AI prompt..."
                      className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50 resize-none"
                      defaultValue="Analyze the incoming lead email and score from 0-100 based on buying intent, budget indicators, and urgency."
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Temperature</label>
                    <input type="range" min="0" max="100" defaultValue="30" className="w-full mt-1.5 accent-violet-500" />
                    <div className="flex justify-between text-xs text-slate-500 mt-1"><span>Precise</span><span>Creative</span></div>
                  </div>
                </>
              )}

              {selectedNodeData.type === 'trigger' && (
                <>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Trigger Source</label>
                    <input
                      placeholder="e.g., leads@company.com"
                      value={selectedNodeData.config.from || ''}
                      onChange={(e) => setNodes(prev => prev.map(n => n.id === selectedNode ? { ...n, config: { ...n.config, from: e.target.value } } : n))}
                      className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50"
                    />
                  </div>
                  {selectedNodeData.category === 'Schedule' && (
                    <div>
                      <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Schedule</label>
                      <select className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                        <option>Every 5 minutes</option>
                        <option>Every 15 minutes</option>
                        <option>Every hour</option>
                        <option>Daily at 9:00 AM</option>
                        <option>Weekly on Monday</option>
                        <option>Custom cron expression</option>
                      </select>
                    </div>
                  )}
                </>
              )}

              {selectedNodeData.type === 'condition' && (
                <div>
                  <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Condition</label>
                  <input
                    placeholder="e.g., score > 70"
                    value={selectedNodeData.config.condition || ''}
                    onChange={(e) => setNodes(prev => prev.map(n => n.id === selectedNode ? { ...n, config: { ...n.config, condition: e.target.value } } : n))}
                    className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50"
                  />
                </div>
              )}

              {selectedNodeData.type === 'action' && (
                <>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Target</label>
                    <input
                      placeholder="e.g., CRM table name"
                      value={selectedNodeData.config.table || selectedNodeData.config.template || ''}
                      onChange={(e) => setNodes(prev => prev.map(n => n.id === selectedNode ? { ...n, config: { ...n.config, table: e.target.value } } : n))}
                      className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Retry on Failure</label>
                    <select className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                      <option>3 times</option>
                      <option>5 times</option>
                      <option>No retry</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 font-medium uppercase tracking-wider">Timeout</label>
                    <select className="w-full mt-1.5 px-3 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl text-white text-sm focus:outline-none focus:border-violet-500/50">
                      <option>30 seconds</option>
                      <option>1 minute</option>
                      <option>5 minutes</option>
                      <option>No timeout</option>
                    </select>
                  </div>
                </>
              )}

              <div className="pt-3 border-t border-slate-800/60 space-y-2">
                <div className="flex gap-2">
                  <button onClick={() => moveNode(selectedNodeData.id, 'up')} className="flex-1 py-2 rounded-xl text-xs text-slate-300 bg-slate-800/50 border border-slate-700/30 hover:bg-slate-700/50 transition-colors">Move Up ↑</button>
                  <button onClick={() => moveNode(selectedNodeData.id, 'down')} className="flex-1 py-2 rounded-xl text-xs text-slate-300 bg-slate-800/50 border border-slate-700/30 hover:bg-slate-700/50 transition-colors">Move Down ↓</button>
                </div>
                <button
                  onClick={() => removeNode(selectedNodeData.id)}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-sm text-red-400 bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete Node
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

# 🧠 SynapseFlow AI

**AI Automation SaaS Platform** — Automate your business with intelligent AI agents, visual workflow builders, and 500+ integrations.

![React](https://img.shields.io/badge/React-19-blue)
![Vite](https://img.shields.io/badge/Vite-7-purple)
![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-4-cyan)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9-blue)

---

## 🚀 Features

- **Dashboard** — Real-time KPIs, charts, and activity logs
- **Visual Workflow Builder** — Drag-in nodes, configure AI models, test runs with step-by-step execution
- **AI Agents** — Deploy, chat, configure, and monitor intelligent agents
- **Integrations Marketplace** — 18+ integrations (Slack, Gmail, Salesforce, Stripe, OpenAI, etc.)
- **Analytics** — Growth trends, ROI tracking, agent performance comparison
- **Settings** — Profile, security (2FA, sessions), billing, API keys
- **Notifications** — Real-time alerts with mark-as-read
- **Help & Docs** — Searchable knowledge base
- **Command Palette** — ⌘K quick navigation

---

## 📂 Project Structure

```
synapseflow-ai/
├── index.html              # Entry HTML
├── netlify.toml            # Netlify deployment config
├── package.json            # Dependencies & scripts
├── vite.config.ts          # Vite build configuration
├── tsconfig.json           # TypeScript configuration
├── .gitignore              # Git ignore rules
├── .nvmrc                  # Node.js version pin
├── README.md               # This file
├── public/
│   └── _redirects          # Netlify SPA fallback (backup)
└── src/
    ├── main.tsx            # React entry point
    ├── App.tsx             # Root component with routing & layout
    ├── index.css           # Global styles & animations
    ├── utils/
    │   └── cn.ts           # Tailwind class merge utility
    ├── components/
    │   ├── Sidebar.tsx     # Navigation sidebar
    │   ├── Modal.tsx       # Reusable modal component
    │   ├── Navbar.tsx      # Landing page navbar
    │   ├── Hero.tsx        # Landing page hero section
    │   ├── Features.tsx    # Features section
    │   ├── Stats.tsx       # Stats bar
    │   ├── HowItWorks.tsx  # How it works section
    │   ├── Testimonials.tsx# Testimonials
    │   ├── Pricing.tsx     # Pricing tiers
    │   ├── Waitlist.tsx    # Waitlist signup form
    │   ├── Footer.tsx      # Footer
    │   └── OutreachHub.tsx # Sales outreach contacts
    └── pages/
        ├── Dashboard.tsx   # Main dashboard
        ├── Workflows.tsx   # Workflow list & management
        ├── WorkflowBuilder.tsx # Visual workflow editor
        ├── Agents.tsx      # AI agent management
        ├── Integrations.tsx# Integration marketplace
        ├── Analytics.tsx   # Analytics & reports
        └── Settings.tsx    # User settings
```

---

## 🛠️ Local Development

### Prerequisites
- Node.js 20+ (see `.nvmrc`)
- npm 9+

### Install & Run

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/synapseflow-ai.git
cd synapseflow-ai

# Install dependencies
npm install

# Start dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Build for Production

```bash
npm run build
```

Output goes to the `dist/` folder.

### Preview Production Build

```bash
npm run preview
```

---

## 🌐 Deploy to Netlify

### Option A: Deploy via GitHub (Recommended)

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit — SynapseFlow AI"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/synapseflow-ai.git
   git push -u origin main
   ```

2. **Connect to Netlify:**
   - Go to [app.netlify.com](https://app.netlify.com)
   - Click **"Add new site"** → **"Import an existing project"**
   - Select **GitHub** → authorize → select `synapseflow-ai` repo
   - Netlify auto-detects settings from `netlify.toml`:
     - Build command: `npm run build`
     - Publish directory: `dist`
   - Click **"Deploy site"**

3. **Done!** Your site will be live at `https://your-site-name.netlify.app`

### Option B: Manual Deploy (Drag & Drop)

1. Build locally: `npm run build`
2. Go to [app.netlify.com](https://app.netlify.com)
3. Drag the `dist/` folder onto the deploy zone
4. Site goes live instantly!

### Option C: Netlify CLI

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login to Netlify
netlify login

# Deploy (first time — creates new site)
netlify deploy --prod --dir=dist
```

---

## ⚙️ Environment Variables (Optional)

If you add backend APIs later, set these in Netlify:

| Variable | Description |
|----------|-------------|
| `VITE_API_URL` | Backend API endpoint |
| `VITE_OPENAI_KEY` | OpenAI API key (for AI agents) |
| `VITE_STRIPE_KEY` | Stripe publishable key |

Set via: **Netlify Dashboard → Site → Site configuration → Environment variables**

---

## 📋 Tech Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| React | 19.2 | UI framework |
| Vite | 7.2 | Build tool & dev server |
| TypeScript | 5.9 | Type safety |
| Tailwind CSS | 4.1 | Utility-first styling |
| Recharts | 3.8 | Charts & data visualization |
| Lucide React | 1.7 | Icon library |
| React Router DOM | 7.13 | Client-side routing |

---

## 📄 License

MIT © SynapseFlow AI

---

**Built with ❤️ by SynapseFlow AI Team**

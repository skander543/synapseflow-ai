import { Cable, Cpu, Rocket } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Cable,
    title: "Connect Your Tools",
    description:
      "Link your existing apps and data sources in minutes. Our one-click integrations make setup effortless — no engineering team required.",
    color: "from-violet-500 to-indigo-500",
  },
  {
    number: "02",
    icon: Cpu,
    title: "Train the AI",
    description:
      "Tell SynapseFlow what you want automated. Our AI learns your processes, understands context, and builds intelligent workflows tailored to you.",
    color: "from-indigo-500 to-cyan-500",
  },
  {
    number: "03",
    icon: Rocket,
    title: "Launch & Scale",
    description:
      "Deploy your automations and watch them run. Monitor performance, iterate quickly, and scale from 10 tasks to 10 million — effortlessly.",
    color: "from-cyan-500 to-emerald-500",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="relative py-24 sm:py-32 bg-slate-950">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-20">
          <span className="inline-block text-sm font-semibold text-cyan-400 tracking-widest uppercase mb-3">How It Works</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Up and Running in
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-violet-400">Three Simple Steps</span>
          </h2>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connecting line */}
          <div className="hidden lg:block absolute top-24 left-[16.67%] right-[16.67%] h-0.5 bg-gradient-to-r from-violet-500/30 via-cyan-500/30 to-emerald-500/30" />

          <div className="grid lg:grid-cols-3 gap-12 lg:gap-8">
            {steps.map((step) => (
              <div key={step.number} className="relative text-center group">
                {/* Step number ring */}
                <div className="relative inline-flex items-center justify-center mb-8">
                  <div className={`h-20 w-20 rounded-full bg-gradient-to-br ${step.color} p-[2px] shadow-lg shadow-violet-500/10 group-hover:shadow-violet-500/25 transition-shadow`}>
                    <div className="h-full w-full rounded-full bg-slate-950 flex items-center justify-center">
                      <step.icon className="h-8 w-8 text-white" />
                    </div>
                  </div>
                  <span className="absolute -top-2 -right-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-violet-400 to-cyan-400 rounded-full h-7 w-7 flex items-center justify-center">
                    {step.number}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-slate-400 leading-relaxed max-w-sm mx-auto">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

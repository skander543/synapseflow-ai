import { Bot, Workflow, Shield, Gauge, Brain, Plug } from "lucide-react";

const features = [
  {
    icon: Bot,
    title: "AI-Powered Agents",
    description: "Deploy intelligent agents that handle customer support, data entry, scheduling, and more — 24/7 without human intervention.",
    color: "from-violet-500 to-violet-600",
    shadowColor: "shadow-violet-500/20",
  },
  {
    icon: Workflow,
    title: "Smart Workflows",
    description: "Build complex automation pipelines with our visual workflow editor. No code required — just drag, drop, and let AI do the rest.",
    color: "from-cyan-500 to-cyan-600",
    shadowColor: "shadow-cyan-500/20",
  },
  {
    icon: Brain,
    title: "Self-Learning System",
    description: "Our AI continuously learns from your data and improves over time. The more you use it, the smarter and faster it gets.",
    color: "from-indigo-500 to-indigo-600",
    shadowColor: "shadow-indigo-500/20",
  },
  {
    icon: Plug,
    title: "500+ Integrations",
    description: "Connect with your favorite tools — Slack, Salesforce, HubSpot, Google Workspace, Zapier, and hundreds more out of the box.",
    color: "from-emerald-500 to-emerald-600",
    shadowColor: "shadow-emerald-500/20",
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "SOC 2 compliant, end-to-end encryption, and role-based access controls. Your data stays safe and private, always.",
    color: "from-amber-500 to-amber-600",
    shadowColor: "shadow-amber-500/20",
  },
  {
    icon: Gauge,
    title: "Real-Time Analytics",
    description: "Monitor automation performance with live dashboards. Track time saved, tasks completed, and ROI in real time.",
    color: "from-rose-500 to-rose-600",
    shadowColor: "shadow-rose-500/20",
  },
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 sm:py-32 bg-slate-950">
      {/* Background accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-violet-600/5 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="inline-block text-sm font-semibold text-violet-400 tracking-widest uppercase mb-3">Features</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Everything You Need to
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">Automate at Scale</span>
          </h2>
          <p className="mt-4 text-slate-400 text-lg max-w-2xl mx-auto">
            From simple task automation to complex multi-step workflows, SynapseFlow gives you the tools to transform how your business operates.
          </p>
        </div>

        {/* Feature grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group relative bg-white/[0.03] border border-white/[0.06] rounded-2xl p-8 hover:bg-white/[0.06] hover:border-white/[0.12] transition-all duration-300"
            >
              <div className={`inline-flex items-center justify-center h-12 w-12 rounded-xl bg-gradient-to-br ${feature.color} shadow-lg ${feature.shadowColor} mb-5`}>
                <feature.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-slate-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

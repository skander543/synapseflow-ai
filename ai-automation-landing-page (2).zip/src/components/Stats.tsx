const stats = [
  { value: "10x", label: "Faster Task Completion" },
  { value: "85%", label: "Reduction in Manual Work" },
  { value: "500+", label: "Integrations Available" },
  { value: "99.9%", label: "Uptime Guaranteed" },
];

export default function Stats() {
  return (
    <section className="relative py-20 bg-slate-950">
      <div className="max-w-7xl mx-auto px-6">
        <div className="relative bg-gradient-to-br from-violet-500/10 to-cyan-500/10 border border-white/[0.06] rounded-3xl p-10 sm:p-16">
          {/* Glow */}
          <div className="absolute inset-0 bg-gradient-to-r from-violet-600/5 to-cyan-600/5 rounded-3xl blur-xl" />

          <div className="relative grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-4">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400 mb-2">
                  {stat.value}
                </div>
                <div className="text-sm sm:text-base text-slate-400 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

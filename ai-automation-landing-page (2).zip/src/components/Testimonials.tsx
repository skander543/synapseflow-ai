import { Quote } from "lucide-react";

const testimonials = [
  {
    quote:
      "SynapseFlow cut our manual data processing time by 90%. What used to take our team hours now happens in minutes, automatically.",
    name: "Sarah Chen",
    role: "VP of Operations",
    company: "TechScale",
    avatar: "SC",
    color: "from-violet-500 to-indigo-500",
  },
  {
    quote:
      "The AI agents are incredible. They handle our customer onboarding flow end-to-end. We've scaled 3x without adding headcount.",
    name: "Marcus Rodriguez",
    role: "CEO & Founder",
    company: "GrowthLab",
    avatar: "MR",
    color: "from-cyan-500 to-emerald-500",
  },
  {
    quote:
      "Finally, an automation tool that actually understands context. SynapseFlow's AI doesn't just follow rules — it thinks.",
    name: "Emily Park",
    role: "Head of Engineering",
    company: "DataForge",
    avatar: "EP",
    color: "from-amber-500 to-orange-500",
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-24 sm:py-32 bg-slate-950">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-sm font-semibold text-violet-400 tracking-widest uppercase mb-3">
            What People Say
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Loved by Early
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">Beta Users</span>
          </h2>
        </div>

        {/* Testimonial cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="relative bg-white/[0.03] border border-white/[0.06] rounded-2xl p-8 hover:bg-white/[0.05] transition-colors"
            >
              <Quote className="h-8 w-8 text-violet-500/30 mb-4" />
              <p className="text-slate-300 leading-relaxed mb-6">"{t.quote}"</p>
              <div className="flex items-center gap-3">
                <div className={`h-10 w-10 rounded-full bg-gradient-to-br ${t.color} flex items-center justify-center text-white text-sm font-bold`}>
                  {t.avatar}
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{t.name}</p>
                  <p className="text-xs text-slate-500">{t.role}, {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

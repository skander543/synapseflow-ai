import { Check, Star } from "lucide-react";

const plans = [
  {
    name: "Starter",
    price: "$49",
    period: "/month",
    description: "Perfect for small teams getting started with AI automation.",
    features: [
      "Up to 1,000 automated tasks/mo",
      "10 active workflows",
      "50+ integrations",
      "Email support",
      "Basic analytics",
    ],
    cta: "Join Waitlist",
    featured: false,
  },
  {
    name: "Pro",
    price: "$149",
    period: "/month",
    description: "For growing businesses that need advanced automation power.",
    features: [
      "Up to 25,000 automated tasks/mo",
      "Unlimited workflows",
      "500+ integrations",
      "Priority support",
      "Advanced analytics & reports",
      "Custom AI model training",
      "Team collaboration tools",
    ],
    cta: "Join Waitlist",
    featured: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    description: "Tailored solutions for large organizations with complex needs.",
    features: [
      "Unlimited automated tasks",
      "Unlimited everything",
      "Dedicated account manager",
      "Custom integrations",
      "On-premise deployment option",
      "SLA & compliance support",
      "24/7 phone & chat support",
    ],
    cta: "Contact Sales",
    featured: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-24 sm:py-32 bg-slate-950">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-indigo-600/5 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="inline-block text-sm font-semibold text-violet-400 tracking-widest uppercase mb-3">Pricing</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Simple, Transparent
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">Pricing for Everyone</span>
          </h2>
          <p className="mt-4 text-slate-400 text-lg max-w-xl mx-auto">
            Start free during early access. Lock in launch pricing by joining the waitlist today.
          </p>
        </div>

        {/* Pricing cards */}
        <div className="grid lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-8 flex flex-col ${
                plan.featured
                  ? "bg-gradient-to-b from-violet-500/10 to-cyan-500/10 border-2 border-violet-500/30 shadow-xl shadow-violet-500/10"
                  : "bg-white/[0.03] border border-white/[0.06]"
              }`}
            >
              {plan.featured && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 inline-flex items-center gap-1.5 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-xs font-bold px-4 py-1.5 rounded-full">
                  <Star className="h-3 w-3" /> MOST POPULAR
                </div>
              )}

              <h3 className="text-xl font-bold text-white">{plan.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold text-white">{plan.price}</span>
                <span className="text-slate-400">{plan.period}</span>
              </div>
              <p className="mt-3 text-slate-400 text-sm leading-relaxed">{plan.description}</p>

              <ul className="mt-8 space-y-3 flex-1">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-cyan-400 shrink-0 mt-0.5" />
                    <span className="text-sm text-slate-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#waitlist"
                className={`mt-8 block text-center font-semibold py-3 rounded-full transition-all ${
                  plan.featured
                    ? "bg-gradient-to-r from-violet-500 to-cyan-500 text-white hover:shadow-lg hover:shadow-violet-500/25"
                    : "bg-white/5 text-white border border-white/10 hover:bg-white/10"
                }`}
              >
                {plan.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

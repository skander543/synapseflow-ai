import { ArrowRight, Sparkles } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-slate-950 pt-20">
      {/* Animated background orbs */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-600/20 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: "2s" }} />
        <div className="absolute top-1/2 left-1/2 w-72 h-72 bg-indigo-500/15 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: "4s" }} />
      </div>

      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 mb-8 animate-fade-in-up">
          <Sparkles className="h-4 w-4 text-violet-400" />
          <span className="text-sm text-slate-300">Now accepting early access signups</span>
        </div>

        {/* Heading */}
        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold text-white leading-tight tracking-tight animate-fade-in-up delay-100" style={{ animationFillMode: "both" }}>
          Automate Your Business
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 via-cyan-400 to-violet-400 animate-gradient">
            With the Power of AI
          </span>
        </h1>

        {/* Subtitle */}
        <p className="mt-6 text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed animate-fade-in-up delay-200" style={{ animationFillMode: "both" }}>
          SynapseFlow connects your tools, automates workflows, and eliminates repetitive tasks — all powered by cutting-edge AI that learns and adapts to your business.
        </p>

        {/* CTA Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up delay-300" style={{ animationFillMode: "both" }}>
          <a
            href="#waitlist"
            className="group inline-flex items-center gap-2 bg-gradient-to-r from-violet-500 to-cyan-500 text-white font-semibold px-8 py-3.5 rounded-full hover:shadow-lg hover:shadow-violet-500/25 transition-all"
          >
            Join the Waitlist
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="#how-it-works"
            className="inline-flex items-center gap-2 text-slate-300 border border-white/10 px-8 py-3.5 rounded-full hover:bg-white/5 transition-colors"
          >
            See How It Works
          </a>
        </div>

        {/* Social proof */}
        <div className="mt-16 animate-fade-in-up delay-400" style={{ animationFillMode: "both" }}>
          <p className="text-sm text-slate-500 mb-4">Trusted by forward-thinking teams at</p>
          <div className="flex items-center justify-center gap-8 flex-wrap opacity-40">
            {["Stripe", "Vercel", "Linear", "Notion", "Figma"].map((brand) => (
              <span key={brand} className="text-lg font-bold text-white tracking-wide">{brand}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-slate-950 to-transparent" />
    </section>
  );
}

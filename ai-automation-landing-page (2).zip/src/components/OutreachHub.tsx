import { useState } from "react";

const potentialBuyers = [
  {
    category: "🏢 AI & Tech Companies (Partnership/Reseller Opportunities)",
    contacts: [
      {
        name: "Pragmatic Coders",
        type: "Software Development Agency",
        location: "Kraków, Poland",
        email: "contact@pragmaticcoders.com",
        phone: "",
        website: "pragmaticcoders.com",
        notes: "Product partner for AI dev — potential white-label or referral deal",
      },
      {
        name: "Crescendo AI",
        type: "AI CX Platform",
        location: "San Francisco, CA",
        email: "info@crescendo.ai",
        phone: "+1.888.410.8077",
        website: "crescendo.ai",
        notes: "AI customer experience — potential integration partner",
      },
      {
        name: "Goldie Agency",
        type: "SEO & Digital Marketing",
        location: "Singapore",
        email: "",
        phone: "+1 (914) 743-0680",
        website: "juliangoldie.com",
        notes: "SEO agency exploring AI automation for clients",
      },
      {
        name: "The AI Automation Agency",
        type: "AI Automation Services",
        location: "United Kingdom",
        email: "",
        phone: "0333 051 0634",
        website: "theaiautomationagency.ai",
        notes: "Bespoke AI for businesses — potential partner or buyer",
      },
      {
        name: "IdeaLink",
        type: "AI Automation Agency",
        location: "Kaunas/Vilnius, Lithuania & London, UK",
        email: "",
        phone: "",
        website: "idealink.tech",
        notes: "No-code AI agency serving 30+ clients — partnership opportunity",
      },
      {
        name: "Kaily AI",
        type: "AI Helpdesk & Voice Platform",
        location: "San Jose, CA (99 S Almaden Blvd, Suite 600)",
        email: "",
        phone: "",
        website: "kaily.ai",
        notes: "AI contact center solutions — integration partner",
      },
      {
        name: "IPH Technologies",
        type: "AI & ML Solutions",
        location: "India",
        email: "",
        phone: "",
        website: "iphtechnologies.com",
        notes: "6x award-winning AI/ML company — reseller opportunity",
      },
      {
        name: "KLYMO",
        type: "AI-Powered Assistants",
        location: "Kyiv, Ukraine",
        email: "",
        phone: "",
        website: "klymo.com",
        notes: "Builds AI assistants for customer communication — under $1K projects",
      },
    ],
  },
  {
    category: "🏠 Real Estate & PropTech (High-Demand Buyers)",
    contacts: [
      {
        name: "EliseAI",
        type: "AI for Housing & Healthcare",
        location: "33 East 33rd St, New York, NY 10016",
        email: "",
        phone: "",
        website: "eliseai.com",
        notes: "Leading conversational AI for real estate — potential buyer/partner",
      },
      {
        name: "PropSys Limited",
        type: "Real Estate CRM & Automation",
        location: "Online",
        email: "",
        phone: "",
        website: "propsys.app",
        notes: "Real estate solutions, CRM, chatbots — needs AI automation",
      },
      {
        name: "CRE Agents",
        type: "Commercial Real Estate AI",
        location: "USA",
        email: "",
        phone: "",
        website: "creagents.ai",
        notes: "AI for commercial real estate — pilot program active, needs automation",
      },
    ],
  },
  {
    category: "📈 Marketing & Growth Agencies (Need AI for Clients)",
    contacts: [
      {
        name: "NoGood",
        type: "Growth Marketing Agency",
        location: "New York, LA, Miami, San Francisco",
        email: "",
        phone: "",
        website: "nogood.io",
        notes: "Works with Fortune 500 & startups — uses AI for lead qualification",
      },
      {
        name: "Estes Media",
        type: "AI Marketing Agency",
        location: "Jersey City, NJ",
        email: "",
        phone: "",
        website: "estesmedia.com",
        notes: "AI-first growth agency for startups & SaaS",
      },
      {
        name: "Maxiom Tech",
        type: "AI Marketing Automation",
        location: "Online",
        email: "",
        phone: "",
        website: "maxiomtech.com",
        notes: "AI marketing automation agency — potential client or partner",
      },
      {
        name: "Automation Agency",
        type: "Marketing Automation for Coaches",
        location: "Online",
        email: "",
        phone: "",
        website: "automationagency.com",
        notes: "Serves coaches & consultants — needs AI automation tools",
      },
    ],
  },
  {
    category: "🎓 Education & Training (Sell AI Curriculum/Tools)",
    contacts: [
      {
        name: "Nucamp Bootcamp",
        type: "Coding Bootcamp",
        location: "Online",
        email: "irene@nucamp.co",
        phone: "",
        website: "nucamp.co",
        notes: "Irene Holden, Operations Manager — teaches AI business ideas",
      },
      {
        name: "Growth Tribe",
        type: "Digital Growth Training",
        location: "Amsterdam, Netherlands",
        email: "",
        phone: "",
        website: "growthtribe.io",
        notes: "Teaches growth hacking, AI, data — needs automation tools",
      },
    ],
  },
  {
    category: "🌐 Data & Web Solutions (Need AI Integration)",
    contacts: [
      {
        name: "DataWay Company",
        type: "Web Solutions & E-Marketing",
        location: "Gaza, Palestine",
        email: "Team@dataway.org",
        phone: "",
        website: "dataway.org",
        notes: "Web dev & e-marketing — needs AI automation for clients",
      },
      {
        name: "Axe Automation",
        type: "AI Automation Agency",
        location: "Online",
        email: "",
        phone: "",
        website: "axeautomation.co",
        notes: "Top AI automation agency — potential partner or buyer",
      },
    ],
  },
];

const leadGenTools = [
  {
    name: "Apollo.io",
    description:
      "Free tier with B2B contact database, email sequencing, and CRM integration. 600M+ contacts.",
    website: "apollo.io",
    free: true,
    highlight: "Best free option to start",
  },
  {
    name: "Instantly.ai",
    description:
      "AI-powered outreach platform with 450M+ B2B leads database. Automated email campaigns.",
    website: "instantly.ai",
    free: true,
    highlight: "Best for cold email at scale",
  },
  {
    name: "Seamless.AI",
    description:
      "AI sales lead search engine with real-time contact verification. 50 free credits.",
    website: "seamless.ai",
    free: true,
    highlight: "Best for phone numbers",
  },
  {
    name: "Lemlist",
    description:
      "600M+ contacts database with multichannel outreach (email, LinkedIn, calls).",
    website: "lemlist.com",
    free: true,
    highlight: "Best for personalized outreach",
  },
  {
    name: "Saleshandy",
    description:
      "800M+ verified contacts with AI search. 75+ filters including tech stack & funding.",
    website: "saleshandy.com",
    free: false,
    highlight: "Best for advanced filtering",
  },
  {
    name: "Kaspr",
    description:
      "LinkedIn-focused lead gen with Chrome extension. Unlimited B2B emails on free tier.",
    website: "kaspr.io",
    free: true,
    highlight: "Best for LinkedIn prospecting",
  },
  {
    name: "ZoomInfo",
    description:
      "Enterprise-grade B2B data platform. 106M+ companies, 140M+ professionals.",
    website: "zoominfo.com",
    free: false,
    highlight: "Best enterprise solution",
  },
  {
    name: "DataToLeads",
    description:
      "1099 business leads with verified email & phone. 100 free B2B phone leads.",
    website: "datatoleads.com",
    free: true,
    highlight: "Best for small business leads",
  },
];

const targetIndustries = [
  {
    industry: "Real Estate",
    reason: "AI lead qualification, virtual staging, automated follow-ups",
    marketSize: "$11.78B AI agents market in 2026",
    urgency: "🔥 Very High",
  },
  {
    industry: "E-Commerce",
    reason: "PPC automation, inventory management, customer service bots",
    marketSize: "Growing rapidly with AI adoption",
    urgency: "🔥 Very High",
  },
  {
    industry: "Marketing Agencies",
    reason: "Content creation, campaign optimization, lead nurturing",
    marketSize: "43% already use AI for repetitive tasks",
    urgency: "🔥 Very High",
  },
  {
    industry: "Healthcare",
    reason: "Patient intake, appointment scheduling, billing automation",
    marketSize: "Prior-auth automation growing fast",
    urgency: "⚡ High",
  },
  {
    industry: "Financial Services",
    reason: "Compliance reporting, risk assessment, document processing",
    marketSize: "Heavily investing in AI automation",
    urgency: "⚡ High",
  },
  {
    industry: "Legal Services",
    reason: "Contract analysis, due diligence, regulatory workflows",
    marketSize: "Document-heavy, ripe for automation",
    urgency: "⚡ High",
  },
  {
    industry: "Contact Centers",
    reason: "AI voice agents, ticket resolution, customer engagement",
    marketSize: "Budget priority #1 is AI/automation",
    urgency: "🔥 Very High",
  },
  {
    industry: "Insurance",
    reason: "Claims processing, underwriting, customer onboarding",
    marketSize: "Compliance-driven automation",
    urgency: "⚡ High",
  },
  {
    industry: "Coaches & Consultants",
    reason: "Onboarding, scheduling, email sequences, CRM",
    marketSize: "$30K–$150K per project, 60-70% margins",
    urgency: "💰 Profitable",
  },
  {
    industry: "Manufacturing",
    reason: "Predictive maintenance, quality control, supply chain",
    marketSize: "Hyper-automation to reach $249B by 2032",
    urgency: "⚡ High",
  },
];

const emailTemplates = [
  {
    name: "Cold Introduction Email",
    subject: "Automate 85% of your manual workflows — here's how",
    body: `Hi [First Name],

I noticed [Company Name] is doing incredible work in [Industry]. I wanted to reach out because we've been helping companies like yours eliminate repetitive tasks and scale operations using AI automation.

At SynapseFlow AI, we build intelligent workflows that:
✅ Reduce manual work by up to 85%
✅ Connect with 500+ tools you already use
✅ Deploy in days, not months

Companies similar to yours have seen 10x productivity gains within the first 30 days.

Would you be open to a quick 15-minute call this week to explore if there's a fit?

Best,
[Your Name]
SynapseFlow AI
[Your Email]`,
  },
  {
    name: "Follow-Up Email",
    subject: "Re: Quick question about automation at [Company]",
    body: `Hi [First Name],

Just following up on my last email. I know you're busy, so I'll keep it brief:

We just helped a [similar industry] company automate their [specific process] and they saved 20+ hours per week.

I'd love to show you exactly how we did it — takes just 15 minutes.

Here's my calendar link: [Calendar Link]

Talk soon,
[Your Name]`,
  },
  {
    name: "Value-First Email",
    subject: "Free AI automation audit for [Company Name]",
    body: `Hi [First Name],

I've been studying [Company Name]'s operations and I see at least 3 areas where AI automation could save your team significant time and money.

I'd love to offer you a complimentary AI Automation Audit where we:
📊 Map your current workflows
🤖 Identify automation opportunities
💰 Estimate potential time & cost savings

No strings attached — just actionable insights you can use whether you work with us or not.

Interested? Just reply "Yes" and I'll send over the details.

Best,
[Your Name]
Founder, SynapseFlow AI`,
  },
];

export default function OutreachHub() {
  const [activeTab, setActiveTab] = useState<"contacts" | "tools" | "industries" | "templates">("contacts");
  const [copiedIndex, setCopiedIndex] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(id);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <section id="outreach" className="py-24 bg-slate-950 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-violet-950/20 via-transparent to-transparent" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="text-violet-400 font-semibold text-sm tracking-widest uppercase">
            📞 Sales Outreach Hub
          </span>
          <h2 className="text-4xl sm:text-5xl font-bold mt-4 mb-6">
            Your{" "}
            <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Lead Database
            </span>{" "}
            & Outreach Kit
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            Curated contacts, lead generation tools, target industries, and email
            templates to start selling SynapseFlow AI today.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {[
            { key: "contacts", label: "📋 Contacts & Leads", count: potentialBuyers.reduce((sum, c) => sum + c.contacts.length, 0) },
            { key: "tools", label: "🔧 Lead Gen Tools", count: leadGenTools.length },
            { key: "industries", label: "🎯 Target Industries", count: targetIndustries.length },
            { key: "templates", label: "✉️ Email Templates", count: emailTemplates.length },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as typeof activeTab)}
              className={`px-5 py-3 rounded-xl font-medium text-sm transition-all ${
                activeTab === tab.key
                  ? "bg-gradient-to-r from-violet-600 to-cyan-500 text-white shadow-lg shadow-violet-500/25"
                  : "bg-slate-800/50 text-slate-400 hover:bg-slate-700/50 hover:text-white border border-slate-700/50"
              }`}
            >
              {tab.label}{" "}
              <span className="ml-1 bg-white/20 px-2 py-0.5 rounded-full text-xs">
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Contacts Tab */}
        {activeTab === "contacts" && (
          <div className="space-y-8">
            {potentialBuyers.map((category, catIdx) => (
              <div key={catIdx}>
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  {category.category}
                  <span className="text-sm font-normal bg-violet-500/20 text-violet-300 px-3 py-1 rounded-full">
                    {category.contacts.length} contacts
                  </span>
                </h3>
                <div className="grid gap-4 md:grid-cols-2">
                  {category.contacts.map((contact, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 hover:border-violet-500/30 transition-all group"
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="text-lg font-bold text-white group-hover:text-violet-300 transition-colors">
                            {contact.name}
                          </h4>
                          <p className="text-sm text-slate-400">{contact.type}</p>
                        </div>
                        <a
                          href={`https://${contact.website}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs bg-slate-800 hover:bg-violet-600 text-slate-300 hover:text-white px-3 py-1.5 rounded-lg transition-all"
                        >
                          🌐 Visit
                        </a>
                      </div>
                      <p className="text-sm text-slate-500 mb-3">📍 {contact.location}</p>
                      <div className="space-y-2">
                        {contact.email && (
                          <div className="flex items-center gap-2">
                            <span className="text-green-400 text-sm">✉️</span>
                            <a
                              href={`mailto:${contact.email}`}
                              className="text-sm text-cyan-400 hover:text-cyan-300 underline"
                            >
                              {contact.email}
                            </a>
                            <button
                              onClick={() => copyToClipboard(contact.email, `email-${catIdx}-${idx}`)}
                              className="text-xs bg-slate-800 hover:bg-green-600 px-2 py-1 rounded transition-all text-slate-400 hover:text-white"
                            >
                              {copiedIndex === `email-${catIdx}-${idx}` ? "✓ Copied!" : "Copy"}
                            </button>
                          </div>
                        )}
                        {contact.phone && (
                          <div className="flex items-center gap-2">
                            <span className="text-blue-400 text-sm">📞</span>
                            <a
                              href={`tel:${contact.phone}`}
                              className="text-sm text-blue-400 hover:text-blue-300"
                            >
                              {contact.phone}
                            </a>
                            <button
                              onClick={() => copyToClipboard(contact.phone, `phone-${catIdx}-${idx}`)}
                              className="text-xs bg-slate-800 hover:bg-blue-600 px-2 py-1 rounded transition-all text-slate-400 hover:text-white"
                            >
                              {copiedIndex === `phone-${catIdx}-${idx}` ? "✓ Copied!" : "Copy"}
                            </button>
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-amber-400/80 mt-3 bg-amber-500/10 px-3 py-2 rounded-lg">
                        💡 {contact.notes}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Lead Gen Tools Tab */}
        {activeTab === "tools" && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {leadGenTools.map((tool, idx) => (
              <div
                key={idx}
                className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 hover:border-cyan-500/30 transition-all relative overflow-hidden group"
              >
                {tool.free && (
                  <span className="absolute top-3 right-3 bg-green-500/20 text-green-400 text-xs px-2 py-1 rounded-full font-medium">
                    ✅ Free Tier
                  </span>
                )}
                <h4 className="text-lg font-bold text-white mb-2 group-hover:text-cyan-300 transition-colors">
                  {tool.name}
                </h4>
                <p className="text-sm text-slate-400 mb-3">{tool.description}</p>
                <p className="text-xs text-cyan-400 font-medium mb-4">
                  ⭐ {tool.highlight}
                </p>
                <a
                  href={`https://${tool.website}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-center bg-gradient-to-r from-violet-600 to-cyan-500 hover:from-violet-500 hover:to-cyan-400 text-white py-2 px-4 rounded-xl text-sm font-medium transition-all"
                >
                  Try {tool.name} →
                </a>
              </div>
            ))}
          </div>
        )}

        {/* Target Industries Tab */}
        {activeTab === "industries" && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {targetIndustries.map((ind, idx) => (
              <div
                key={idx}
                className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 hover:border-amber-500/30 transition-all"
              >
                <div className="flex justify-between items-start mb-3">
                  <h4 className="text-lg font-bold text-white">{ind.industry}</h4>
                  <span className="text-sm whitespace-nowrap">{ind.urgency}</span>
                </div>
                <p className="text-sm text-slate-400 mb-3">{ind.reason}</p>
                <p className="text-xs text-violet-400 bg-violet-500/10 px-3 py-2 rounded-lg">
                  📊 {ind.marketSize}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Email Templates Tab */}
        {activeTab === "templates" && (
          <div className="space-y-6">
            {emailTemplates.map((template, idx) => (
              <div
                key={idx}
                className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 hover:border-violet-500/30 transition-all"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-lg font-bold text-white">{template.name}</h4>
                    <p className="text-sm text-cyan-400 mt-1">
                      Subject: {template.subject}
                    </p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(template.body, `template-${idx}`)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      copiedIndex === `template-${idx}`
                        ? "bg-green-500 text-white"
                        : "bg-violet-600 hover:bg-violet-500 text-white"
                    }`}
                  >
                    {copiedIndex === `template-${idx}` ? "✓ Copied!" : "📋 Copy Template"}
                  </button>
                </div>
                <pre className="text-sm text-slate-300 bg-slate-950 rounded-xl p-4 overflow-x-auto whitespace-pre-wrap font-mono leading-relaxed border border-slate-800">
                  {template.body}
                </pre>
              </div>
            ))}
          </div>
        )}

        {/* Action Plan */}
        <div className="mt-16 bg-gradient-to-r from-violet-900/30 to-cyan-900/30 border border-violet-500/20 rounded-3xl p-8">
          <h3 className="text-2xl font-bold text-white mb-6 text-center">
            🚀 Your 5-Step Outreach Action Plan
          </h3>
          <div className="grid md:grid-cols-5 gap-4">
            {[
              {
                step: "1",
                title: "Sign Up",
                desc: "Create free accounts on Apollo.io, Instantly.ai, and Kaspr",
              },
              {
                step: "2",
                title: "Build Lists",
                desc: "Search for decision-makers in Real Estate, E-Commerce & Marketing",
              },
              {
                step: "3",
                title: "Personalize",
                desc: "Use our email templates and customize for each prospect",
              },
              {
                step: "4",
                title: "Send",
                desc: "Launch campaigns with 50-100 personalized emails per day",
              },
              {
                step: "5",
                title: "Follow Up",
                desc: "Use the follow-up template 3-5 days after initial contact",
              },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-12 h-12 bg-gradient-to-r from-violet-600 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-lg mx-auto mb-3">
                  {item.step}
                </div>
                <h4 className="font-bold text-white mb-1">{item.title}</h4>
                <p className="text-xs text-slate-400">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
